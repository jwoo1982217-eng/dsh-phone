---
name: packer-solutions
description: 按加固类型查阅加固解法1.1原始教程，并将教程落实为 APK 脱壳、DEX 修复、入口还原、加固残留清理、重打包及运行验证。用于百度、360、蛮犀、爱加密、腾讯御安全、深思数盾、顶象、随风、梆梆加固的分析或修复任务。
---

# 加固解法

把用户提供的「加固解法1.1」教程用在具体 APK 上。原始教程与 Lua 文件在 `references/original/`，按当前加固类型读取对应文件。资料记录的是特定工具与壳版本的做法，先核对实际 APK 与工具版本，再决定哪些步骤适用。

## 任务流程

1. 明确输入 APK、已脱出的 DEX、当前故障及用户要交付的结果；能从本机材料发现的信息直接检查。
2. 结合 Manifest 的 application／componentFactory、壳入口类、assets 与 native 库识别加固类型。证据不够时给出候选与验证办法，不把猜测写成定论。
3. 读取下表对应教程，把步骤映射到实际文件与可用工具。对不同 360 工具版本分别选择方法，避免混用目录结构。教程引用“看图”而包内没有图片时，直接核对实际类或 Manifest，说明缺失的依据。
4. 在工作副本处理 DEX 修复、命名、入口还原、残留清理与重打包。保留输入，记录改动路径；没有对应执行工具时交付明确的操作步骤与待验证项。Lua 文件作为配套脚本按需检查，导入本技能不运行它。
5. 核验 DEX 与 Manifest 可解析、入口类实际存在、重复类和架构目录是否一致、ZIP 完整性及签名；具备设备条件时安装并检查启动和相关功能。区分“重打包成功”与“已在设备运行成功”。

## 教程路由

| 加固或问题 | 按需读取 |
|---|---|
| 百度 | [教程](references/original/百度加固/教程.txt) |
| 360，NP 3.0／assets app_dex | [方法一](references/original/360加固/方法一/去签np3.0.txt) |
| 360，NP 2.0／DEX 合并 | [方法二](references/original/360加固/方法二/去签np2.0.txt) |
| 360，方法二的变体 | [方法三](references/original/360加固/方法三/进来看看.txt)，结合方法二阅读 |
| 360，配套 Lua 脚本 | [新版360脱壳脚本](references/original/360加固/新版360脱壳脚本.lua) |
| 蛮犀 | [教程](references/original/蛮犀加固/教程.txt) |
| 爱加密 | [文字教程](references/original/爱加密脱壳/文字教程.txt)、[简版](references/original/爱加密脱壳/教程.txt) |
| 腾讯御安全 | [教程](references/original/腾讯御安全脱壳/教程.txt) |
| 深思数盾 | [教程](references/original/深思数盾/教程(来自于mt论坛_波波菌).txt) |
| 顶象 | [教程](references/original/顶象加固/教程.txt) |
| 随风 | [教程](references/original/随风加固/教程.txt) |
| 梆梆 | [教程](references/original/梆梆加固/教程.txt) |
| application 入口字段 | [入口文件](references/original/入口文件.txt) |
| XML 属性删除问题 | [原始注意事项](references/original/xml删除数据注意.txt)；实际编辑后重新解析 XML，不能只凭字符片段判断有效性 |

## 交付

给出识别证据、采用的教程及版本、实际改动、输出路径和验证结果。保留原文中涉及的工具名及相应条件；没有完成的脱壳、安装或运行验证明确列为未完成，不用教程存在代替执行证据。
