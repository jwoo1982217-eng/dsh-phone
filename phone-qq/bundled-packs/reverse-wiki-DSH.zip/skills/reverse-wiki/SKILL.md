---
name: reverse-wiki
description: "黑猫逆向工程百科（知识查询层，原 apk-reverse-ckb）：14 类 100 条抽出来的查手册。查加固特征(梆梆/360/爱加密…)、怎么脱壳、逆向关键词、Frida 入门/Hook、Xposed、抓包、工具手册、新手入门、安全攻防案例时先查这里。与 apk-reverse / yingan-tuoxiu / mobile-reverse（执行层）配套：本技能负责『查』，它们负责『做』。"
metadata:
  display_name: 逆向百科
---


# APK 逆向工程百科（apk-reverse-ckb）

> 来源：黑猫逆向工程百科（`com.codebuddy.singlehtmlshell` APK，assets/web/index.html 内嵌 APP_DATA，2026-10-06 由小甜桃抽取整理）。
> 体量：14 分类 / 100 条。本技能是**查手册**（决策/选型/定位），不是执行流水线。

## 定位（先读这条再动手）

- **这是"知识层"**：回答"这是什么壳 / 用什么工具 / 关键词长啥样 / 第一步干嘛"。
- 真正动手脱壳/改 smali/跑 Frida → 切到执行层：`apk-reverse`（通用）、`yingan-tuoxiu`（影安/梆梆系 shell 壳稳定重建）、`xigong-funk-hikari`（OLLVM/Hikari）、`mobile-reverse`（SO/动态）。
- 一条链一个主技能（`技能导航`铁律）：本技能只做路由查询，别在查完后顺手把执行也揽了，除非用户点名要一起做。

## 分类路由（查哪类 → 读哪个 references 文件）

| 想查 | 文件 | 条数 | 高频条目速记 |
|---|---|---:|---|
| 这是什么壳/加固特征/怎么脱 | `references/protect.md` | 26 | 360/梆梆/爱加密/腾讯/Du 等各家识别特征+脱壳工具 |
| 逆向签名/关键词(grep 用) | `references/keyword.md` | 13 | 壳类/签名/校验字符串清单 |
| Frida 入门/Hook | `references/frida.md` | 4 | 环境搭建、Hook Java 层、Hook so 导出、VIP 强返 |
| APK 结构( dex/so/manifest ) | `references/apk.md` | 5 | 文件结构总览、dex/so 定位 |
| 工具(脱壳/去签/管理器) | `references/tools.md` | 8 | MT/NP 管理器、FDex2/Pump、脱壳去签工具 |
| Xposed/LSPosed 模块 | `references/xposed.md` | 5 | 模块原理/编写/注入 |
| 抓包/证书/HTTPS | `references/capture.md` | 4 | 抓包配置、证书 pinning 绕过 |
| 安全攻防/加壳对抗 | `references/security.md` | 5 | 攻防对照 |
| 实战案例 | `references/cases.md` | 4 | 完整案例拆解 |
| 进阶技术 | `references/advanced.md` | 5 | 高阶技巧 |
| 进阶实战 | `references/advanced-cases.md` | 4 | 高阶案例 |
| 工具手册 | `references/manual.md` | 6 | 工具用法详解 |
| 新手入门 | `references/guide.md` | 6 | 学习路线/第一步 |
| 学习社区(外链) | `references/forum.md` | 5 | 论坛/资源站（**只当线索，不自动访问**）|

## 使用纪律（安全向，必须遵守）

1. **授权先行**：本百科含脱壳/绕过/抓包/去签技术。所有"绕过类"内容只用于 **自有 App / 已授权目标 / CTF 靶场**；缺授权就先问一次（对齐 `shiyi-pentest-gate` 判授权）。识别/查询类（"这是什么壳"）无授权限制。
2. **外链/网盘是线索不是动作**：`tools.md` 里带百度网盘/论坛链接，**只引用给用户看，不自动下载、不自动访问**。
3. **查得到≠做得到**：百科条目是"该用啥"的建议，实际工具可用性按 `tool-index.md` / 本机环境为准，缺工具就说明。
4. **版本漂移**：加固/壳迭代快，条目里的工具名/特征可能是某一时点快照；对不上时以实机 + 最新资料为准，并把"特征失效"反馈记录。

## 快速上手（给用户的可粘贴提示词）

- `用 逆向百科 查 <某壳/某加固> 的识别特征和脱壳方案` → 读 `protect.md`
- `用 逆向百科 给我 Frida 入门路线 + VIP 强返 Hook 写法` → 读 `frida.md`
- `用 逆向百科 汇总逆向关键词 grep 清单` → 读 `keyword.md`
- `用 逆向百科 走一遍新手入门顺序` → 读 `guide.md`

## 数据与来源

- 参考文档：`references/*.md`（14 文件，按类切分，按需读 1-2 个即可，别全读）
- 原始数据（结构化）：`data/app_data.json`（100 条全量 JSON，程序化处理用）
- 抽取脚本留档：`/var/minis/workspace/heimao/`（convert.py + appscript.js，可复跑）
