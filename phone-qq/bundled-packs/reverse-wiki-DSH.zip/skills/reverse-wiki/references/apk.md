# APK架构
> 分类 `apk` · 5 条 · 来源：黑猫逆向工程百科（APK 抽取，2026-10-06）

## APK文件结构总览 `#基础`
- MT管理器可直接查看
- 详解：APK文件结构总览

### APK本质
- APK文件本质是一个ZIP压缩包
- 修改后缀为.zip即可用文件管理器解压
- 可用MT管理器直接查看内部结构无需解压

### 核心文件目录
- AndroidManifest.xml：应用配置、权限、组件声明
- classes.dex：Java字节码文件（核心代码）
- resources.arsc：编译后的资源索引表
- lib/：Native库文件(.so)
- assets/：原始资源文件
- META-INF/：签名信息

### 手机端查看方法
- MT管理器点击APK选择「查看」
- 可浏览所有文件和目录结构
- 支持直接查看AndroidManifest.xml文本
- DEX文件可调用内置jadx反编译

### 修改注意事项
```
修改后需要重新压缩为APK格式
必须重新签名才能安装
classes.dex修改后需对齐(zipalign)
```
> 提示：MT管理器是最方便的手机端APK分析工具，支持查看、编辑、签名一条龙。

## AndroidManifest解析 `#核心`
- 入口Activity/权限/组件
- 详解：AndroidManifest.xml 深度解析

### 什么是AndroidManifest
- 每个APK必须包含的配置文件
- 声明应用包名、版本、权限、组件等信息
- 系统在安装APK时首先读取此文件
- 逆向时通过它快速了解APP结构

### 关键节点解析
- package="com.xxx.app" → 应用唯一包名
- application → 应用全局配置入口
- activity → 界面Activity，带intent-filter的是主入口
- service → 后台服务组件
- receiver → 广播接收器
- provider → 内容提供者

### 权限声明解读
- uses-permission → 申请的系统权限
- 如INTERNET、READ_PHONE_STATE等
- 敏感权限越多说明功能越复杂
- 逆向时关注权限与功能是否匹配

### 手机端查看方式
- MT管理器：APK→查看→AndroidManifest.xml
- jadx手机版：反编译后直接查看
- NP管理器：APK信息页展示关键内容
- 开发者助手：一键提取并解析

### 逆向技巧
- 查找主入口Activity快速定位启动逻辑
- 分析所有 exported="true" 的组件
- 通过权限反推APP涉及的功能模块
- 修改android:label改应用名称
> 提示：AndroidManifest是逆向分析的第一站，看懂它能帮你快速建立对APP的整体认知。

## DEX文件格式详解 `#进阶`
- classes.dex反编译
- 详解：DEX文件格式与反编译

### 什么是DEX
- DEX = Dalvik Executable
- Android虚拟机的执行文件格式
- 由Java源码编译后的.class文件转换而来
- 一个APK通常包含1个classes.dex

### DEX文件结构
- 文件头：magic、checksum、文件大小等
- 字符串池：所有字符串常量集中存放
- 类型池：类、方法、字段的类型信息
- 方法池：所有方法的定义
- 类数据区：类的字段、方法、代码等
- 代码区：smali字节码指令

### 反编译原理
- dex → smali：将字节码转为汇编级指令
- dex → java：通过jadx还原为近似Java代码
- 反编译出的Java并非100%原始代码
- 但足够理解逻辑和定位关键函数

### 手机端反编译方法
- MT管理器：查看DEX→调用内置jadx反编译
- jadx手机版：直接打开APK自动反编译
- NP管理器：DEX编辑器查看smali
- 开发者助手：一键提取并查看Java代码

### 实战技巧
- 多dex应用注意搜索所有dex文件
- 加固APP的dex可能被加密或替换
- 反编译失败尝试先脱壳再反编译
- 混淆代码变量名被替换为a/b/c
> 提示：jadx反编译是目前最准确的dex→Java还原工具，手机版功能已足够日常使用。

## 资源文件arsc分析 `#资源`
- resources.arsc字符串
- 详解：resources.arsc 资源索引分析

### 什么是arsc
- arsc = Android Resource Compiled
- 编译后的二进制资源索引文件
- 将res/目录下的所有资源打包并建立索引
- APP运行时通过资源ID快速查找

### 包含哪些资源
- 字符串资源：strings.xml中定义的所有文本
- 布局资源：layout/*.xml的布局文件
- 图片资源：drawable/mipmap中的图片
- 颜色/尺寸/样式等配置资源

### 逆向中的应用
- 修改APP名称：替换app_name字符串
- 去广告：删除或修改广告布局资源ID
- 汉化：替换英文字符串为中文
- 替换图片：修改logo或启动图
- 分析界面：通过布局名定位Activity

### 手机端编辑方法
- MT管理器：Arsc编辑器直接修改字符串
- 修改后保存APK并重新签名
- MT还支持批量替换和翻译功能
> 提示：resources.arsc是APP的"字典"，掌握它能帮你快速找到要修改的字符串和界面元素。

## Native库so分析 `#Native`
- lib/arm64-v8a/*.so
- 详解：Native库(.so) 逆向分析

### 什么是so库
- so = Shared Object（共享对象）
- Linux/Android平台的动态链接库文件
- 类似于Windows的.dll文件
- 由C/C++代码编译生成，通过JNI与Java交互

### 存放位置
- lib/armeabi-v7a/ → 32位ARM处理器
- lib/arm64-v8a/ → 64位ARM处理器（主流）
- lib/x86/ → 模拟器/x86设备
- APP会根据设备架构自动加载对应so

### 为什么分析so
- 核心算法（加密/解密）常在so中实现
- 加固/防破解逻辑在Native层执行
- Java层仅做调用，真实逻辑在so中
- so比Java更难反编译，保护力度更强

### JNI函数命名规律
- Java_com_xxx_ClassName_methodName
- 包名中的点替换为下划线
- 找到JNI函数就找到了Java和Native的桥梁
> 提示：Native层是逆向的深水区，建议先掌握Java层Hook，再逐步学习so分析。
