# 新手入门
> 分类 `guide` · 6 条 · 来源：黑猫逆向工程百科（APK 抽取，2026-10-06）

## 环境准备 `#第1步`
- MT管理器+NP管理器安装
- 详解：第一步：环境准备

### 必备工具
- MT管理器：文件管理+APK编辑
- NP管理器：APK反编译回编
- 开发者助手：布局分析
- 反射大师：免Root Hook

### 进阶工具（可选）
- Magisk+LSPosed：Root+Hook框架
- Frida-Server：动态Hook
- jadx手机版：反编译工具
- HttpCanary/ProxyPin：抓包工具

### 学习资源
- 52破解论坛入门帖
- MT论坛教程区
- 本百科全部内容
- B站相关视频教程

### 心理准备
- 逆向需要耐心，不要急于求成
- 从简单目标开始练习
- 遇到问题先搜索再提问
- 建立系统的知识体系
> 提示：工具不需要全部安装，先从MT管理器+反射大师开始即可入门。

## APK结构认识 `#第2步`
- MT查看APK内部文件
- 详解：第二步：认识APK结构

### 学习目标
- 了解APK是ZIP压缩包
- 认识AndroidManifest.xml
- 了解classes.dex是核心代码
- 了解resources.arsc是资源索引

### 实操练习
- 用MT管理器打开任意APK
- 浏览内部文件和目录
- 查看AndroidManifest.xml
- 用Arsc编辑器查看字符串资源

### 关键认知
- APK修改后需要重新签名
- 签名用于验证APK完整性
- dex文件包含Java代码
- so文件包含Native代码
> 提示：这一步不用修改任何文件，只是观察和了解APK内部结构。

## smali修改入门 `#第3步`
- MT编辑smali代码
- 详解：第三步：smali修改入门

### 学习目标
- 了解smali是dex的汇编形式
- 学会定位方法体的return语句
- 学会将return false改为return true
- 学会保存并重新签名

### 实操练习
- 找一个无加固的简单APP
- MT管理器→DEX编辑器
- 搜索关键词定位方法
- 修改return值
- 保存并签名安装
- 测试修改效果

### 常见修改
```
isVip() → return true
isAdEnabled() → return false
checkLogin() → return true
canUseFeature() → return true
```
> 提示：smali修改是最基础的逆向操作，成功一次后就入门了。

## 关键词定位 `#第4步`
- jadx手机版搜索定位
- 详解：第四步：关键词定位技巧

### 学习目标
- 掌握常用的逆向关键词
- 学会用jadx/MT搜索定位
- 理解搜索结果的含义
- 快速找到关键逻辑

### 实操练习
- 打开jadx手机版加载APK
- 搜索"isVip""checkVip"等关键词
- 找到对应类和方法
- 分析调用关系
- 确定修改点

### 关键词列表
- VIP相关：isVip, isPremium, isMember
- 广告相关：showAd, loadAd, AdView
- 登录相关：login, token, sign
- 时间相关：expire, validTime
> 提示：关键词定位是逆向的核心技能，掌握后效率提升10倍。

## Hook实战 `#第5步`
- 反射大师/Frida手机Hook
- 详解：第五步：Hook实战

### 学习目标
- 理解Hook是运行时修改行为
- 掌握反射大师的基本用法
- 或掌握Frida基础语法
- 实现不修改APK的破解

### 反射大师练习
- 安装反射大师
- 选择一个简单APP
- Hook isVip返回true
- 测试效果
- 尝试Hook其他方法

### Frida练习（进阶）
- 安装Frida-Server
- 编写简单Hook脚本
- Hook Java方法打印日志
- 修改返回值
- 过渡到Native Hook
> 提示：Hook是逆向的进阶技能，掌握后可以实现更灵活的破解方案。

## 去广告实战 `#实战`
- 布局分析+关键字跳过
- 详解：去广告实战综合练习

### 目标APP选择
- 选择一个有开屏广告或Banner广告的APP
- 无加固或低加固优先
- 广告SDK为穿山甲、优量汇等常见类型
- 自己常用的APP更有动力

### 分析步骤
- 开发者助手查看广告View的ID
- jadx搜索广告SDK相关类
- 分析广告加载和展示逻辑
- 确定Hook或修改点

### 实施方案
- 方案A：反射大师Hook showAd() return
- 方案B：MT管理器修改smali
- 方案C：Frida脚本自动Hook
- 测试验证广告是否消失

### 进阶练习
- 尝试Hook不同广告SDK
- 处理多种广告类型（开屏、插屏、Banner）
- 解决去广告后的空白占位问题
- 编写通用的去广告模块
> 提示：去广告是练习逆向的最佳实战项目，成就感强且难度适中。
