# 高级技术
> 分类 `advanced` · 5 条 · 来源：黑猫逆向工程百科（APK 抽取，2026-10-06）

## 虚拟机检测绕过 `#检测`
- Build.FINGERPRINT等特征
- 详解：虚拟机检测绕过技术

### 检测方式
- Build.FINGERPRINT包含"generic"等模拟器特征
- Build.MODEL为"sdk"或模拟器型号
- /proc/cpuinfo中有hypervisor标识
- 检查特定模拟器文件（如qemu_pipe）

### 绕过方案A：Hook Build字段
- Hook Build.FINGERPRINT返回真实手机值
- Hook Build.MODEL返回真实型号
- Hook Build.BOARD返回真实主板信息

### 绕过方案B：Magisk模块
- 安装"Hide Props Config"模块
- 设置设备指纹为真实手机
- 自动处理所有Build字段

### 绕过方案C：文件隐藏
```
用Magisk的MagiskHide隐藏模拟器文件
或Hook File.exists()让检测不到
配合Shamiko模块隐藏Root痕迹
```
> 提示：模拟器检测是多层组合的，需要同时Hook多个检测点。

## 代码混淆对抗 `#混淆`
- ProGuard/R8/OLLVM还原
- 详解：代码混淆对抗技术

### 混淆类型
- ProGuard/R8：类名、方法名、变量名混淆
- OLLVM：控制流平坦化、虚假分支
- 字符串加密：运行时解密
- 反射调用：间接调用方法

### 对抗方案A：Hook解密
- Hook字符串解密函数获取明文
- Hook反射调用追踪真实目标
- 打印所有动态调用的方法名

### 对抗方案B：动态分析
- 用Frida Hook跟踪执行流程
- 打印每个方法的调用栈
- 分析真实的控制流走向

### 对抗方案C：符号还原
- 对比未混淆版本的映射关系
- 根据方法参数和返回值推测功能
- 用注释标记已分析的混淆方法
> 提示：混淆只能增加分析时间，不能阻止分析，耐心Hook追踪即可还原逻辑。

## 完整性校验绕过 `#校验`
- 签名/hash/文件校验跳过
- 详解：完整性校验绕过技术

### 校验类型
- 签名校验：验证APK签名是否被修改
- Hash校验：验证文件完整性
- 文件存在校验：检查关键文件是否存在
- 代码段校验：校验classes.dex完整性

### 绕过方案A：Hook校验函数
- Hook签名校验返回true
- Hook hash校验返回匹配
- Hook文件存在校验返回存在

### 绕过方案B：修复签名
- 用原始密钥重新签名
- 或计算修改后的新hash
- 让校验函数通过

### 绕过方案C：NOP校验代码
- 找到校验代码的smali
- 将校验逻辑替换为nop或return-true
- 永久去除校验
> 提示：完整性校验是APK修改后的常见障碍，Hook校验函数是最通用的方案。

## 反调试反Hook对抗 `#对抗`
- ptrace/status检测绕过
- 详解：反调试反Hook对抗技术

### 反调试手段
```
ptrace(PTRACE_TRACEME)防止调试
检测/proc/self/status中的TracerPid
循环检测isDebuggerConnected()
校验代码完整性
```

### 反Hook手段
- 检测Frida端口(27042)
- 检测/frida-server进程
- 检测特定内存特征
- 检测Xposed框架文件

### 对抗方案A：Hook检测
- Hook ptrace直接返回
- Hook isDebuggerConnected返回false
- Hook文件检测返回不存在

### 对抗方案B：隐藏痕迹
- 用Magisk模块隐藏Frida/Xposed文件
- 修改/proc/pid/maps隐藏内存特征
- 用Shamiko模块全面隐藏
> 提示：反调试对抗是高阶内容，新手遇到建议先用现成方案，不要硬刚。

## 网络协议逆向 `#协议`
- 手机抓包分析API接口
- 详解：网络协议逆向分析

### 分析步骤
- 抓包获取完整请求和响应
- 分析请求头、参数、响应格式
- 定位关键API接口
- 分析签名/加密逻辑

### 协议还原
- 用Postman复现请求
- 用Python requests实现自动化
- 分析protobuf/grpc等特殊协议
- 还原WebSocket通信流程

### 自动化工具
- mitmproxy：中间人代理，可编程
- Charles Map Remote：映射到本地
- Frida Hook网络请求打印详情
- 自己写Python脚本批量测试
> 提示：协议分析是逆向的高级阶段，掌握后可以完全脱离APP操作后端接口。
