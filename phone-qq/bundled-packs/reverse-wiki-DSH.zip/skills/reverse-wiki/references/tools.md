# 逆向工具
> 分类 `tools` · 8 条 · 来源：黑猫逆向工程百科（APK 抽取，2026-10-06）

## 逆向去签脱壳工具 `#2j36`
- NP/MT管理器等脱壳签名工具
- 资源链接：https://pan.baidu.com/s/127ANKhmoNvW5C2KaYdrc7A?pwd=2j36
- 详解：逆向去签脱壳工具包

### 包含工具
- NP管理器：APK反编译、修改、回编、签名
- MT管理器：双窗口文件管理+APK编辑神器
- 一键去签工具：自动去除APK签名验证
- ApkSigner：V1/V2/V3签名工具

### 使用场景
- APK修改后需要重新签名才能安装
- 去除原签名防止校验失败
- 加固APK脱壳后修复签名

### 手机端操作步骤
- 用MT管理器打开目标APK
- 进入DEX编辑器或Arsc编辑器修改
- 保存后使用功能-APK签名
- 选择密钥或自动生成测试签名

### 注意事项
- 测试签名仅用于个人学习，不可发布
- 部分应用有二次签名校验需要额外处理
- V3签名需要Android 9+设备支持
> 提示：MT管理器的签名功能在功能菜单中，支持自定义密钥和自动测试签名。

## 抓包工具合集 `#pnxv`
- Charles/Fiddler/HttpCanary
- 资源链接：https://pan.baidu.com/s/1EHz9naLSAzRB2ocM1zJOPA?pwd=pnxv
- 详解：抓包工具合集使用指南

### 工具列表
- Charles：PC端专业抓包，支持断点调试
- Fiddler：免费抓包，脚本扩展能力强
- HttpCanary(小黄鸟)：安卓端抓包神器
- ProxyPin：免Root VPN模式抓包

### 手机端抓包配置
- 安装HttpCanary或ProxyPin
- 配置VPN证书（Android 7+需系统证书）
- 启动抓包，打开目标APP
- 分析请求头、参数、响应数据

### HTTPS证书安装
- HttpCanary：自动生成本地证书，部分应用需Root
- ProxyPin：VPN模式无需系统证书
- Android 7+用户证书默认不被信任
- 需将证书移至/system/etc/security/cacerts/

### 常见问题
```
APP走自己的SSL校验：需配合Frida Hook绕过
证书绑定(Certificate Pinning)：用Objection禁用
部分APP检测代理：用VPN模式绕过
```
> 提示：手机抓包推荐ProxyPin免Root方案，或者搭配Magisk模块信任用户证书。

## 布局广告入口 `#byj3`
- 开发者助手定位广告View
- 资源链接：https://pan.baidu.com/s/17Bjumi_UwdS9_mBoiBxWIg?pwd=byj3
- 详解：布局广告入口工具

### 工具功能
- 开发者助手：查看当前界面的View树
- 定位广告控件的ID和类名
- 分析广告布局层级
- 辅助编写去广告Hook脚本

### 使用步骤
- 安装开发者助手APP
- 打开目标APP到广告页面
- 开发者助手悬浮窗查看当前Activity
- 找到广告View的ID（如ad_view、banner）
- 在jadx/MT中搜索该ID定位代码

### 去广告思路
- 找到广告加载代码位置
- Hook showAd()直接return
- 或将广告View设为GONE
- 拦截广告请求返回空数据
> 提示：开发者助手是去广告分析的利器，配合MT管理器的Arsc编辑器效果更佳。

## 开发环境配置包 `#6e22`
- Android Studio/JDK/ADB
- 资源链接：https://pan.baidu.com/s/1mNwM0zUHYHxkJv5W_HJ9bQ?pwd=6e22
- 详解：开发环境配置包

### 包含内容
- Android Studio：官方IDE，APK开发调试
- JDK：Java开发环境，jadx等工具需要
- ADB：Android Debug Bridge，连接手机调试
- Platform-Tools：fastboot、systrace等

### 手机端替代方案
- MT管理器：无需PC即可完成大部分逆向操作
- Termux：手机端Linux环境，安装Python/Frida
- jadx手机版：直接在手机反编译APK
- QPython：手机端Python脚本执行

### ADB常用命令
- adb devices：查看连接设备
- adb install xxx.apk：安装APK
- adb shell：进入手机Shell
- adb push/pull：文件传输
- adb logcat：查看日志
> 提示：纯手机端逆向完全可以不用PC，MT管理器+Termux已经能满足90%的需求。

## 视频教程合集 `#m74i`
- 入门到进阶视频 手机可看
- 资源链接：https://pan.baidu.com/s/1mh-cLEBfycORJt0yx2BX9w?pwd=m74i
- 详解：视频教程合集说明

### 内容涵盖
- Android逆向入门基础
- MT管理器使用教程
- APK去广告实战案例
- Frida Hook入门到进阶
- Xposed模块开发

### 获取方式
- 百度网盘链接
- 提取码：m74i
- 建议手机下载百度网盘APP观看
- 可缓存到本地离线观看

### 学习建议
- 按顺序观看，不要跳步
- 边看边跟着操作
- 准备测试APK实战练习
- 做好笔记建立知识体系
> 提示：视频教程是最直观的学习方式，建议先从基础操作视频开始。

## APK注入工具 `#prcg`
- Frida-Gadget/Xposed注入
- 资源链接：https://pan.baidu.com/s/1UShApazdTVfPeRNfPH20Hw?pwd=prcg
- 详解：APK注入工具说明

### 注入方式
- Frida-Gadget：将frida-gadget.so嵌入APK
- Xposed模块：通过框架注入Hook代码
- 动态加载：运行时加载dex/so文件
- 重打包：修改APK后重新签名

### 使用场景
- 无Root环境下使用Frida
- 持久化Hook某个APP
- 将逆向脚本打包进APK
- 制作修改版APK分发

### 注意事项
- 注入后APK体积会变大
- 部分APP有完整性校验需绕过
- Frida-Gadget需要对应架构版本
- 重打包后需用测试签名
> 提示：APK注入是进阶技术，建议先掌握Frida基础再尝试。

## 模块加密解密 `#n37m`
- 字符串解密/算法还原
- 资源链接：https://pan.baidu.com/s/11d9mQGRqCVRiB-EgpAnGDw?pwd=n37m
- 详解：模块加密解密工具

### 功能说明
- 字符串解密工具：还原加密后的字符串
- 算法还原辅助：分析加密算法参数
- 密钥提取：自动提取so库中的密钥
- Hook脚本模板：快速生成解密Hook

### 使用场景
- APK中字符串被加密无法搜索
- 网络请求参数加密需要还原
- so库中的算法需要逆向分析
- 签名算法需要破解

### 获取方式
- 百度网盘链接
- 提取码：n37m
- 包含多个解密工具和脚本
> 提示：加密解密是逆向深水区，建议先掌握Frida Hook再深入。

## 56.ai在线脱壳 `#在线`
- 手机上传自动脱壳
- 资源链接：https://www.56ai.com
- 详解：56.ai在线脱壳平台

### 平台功能
- 在线自动化脱壳分析
- 上传APK自动识别加固类型
- 自动Dump还原后的Dex
- 支持多种主流加固厂商

### 使用方法
- 手机浏览器访问 www.56ai.com
- 上传需要脱壳的APK文件
- 等待分析完成（几分钟到几十分钟）
- 下载脱壳后的文件

### 注意事项
- 上传文件会发送到服务器，敏感APP慎用
- 脱壳成功率受加固版本影响
- 脱壳后仍需jadx反编译查看代码
- 免费版可能有次数限制
> 提示：56.ai适合新手快速体验脱壳，但敏感APK建议本地处理。
