# Xposed模块
> 分类 `xposed` · 5 条 · 来源：黑猫逆向工程百科（APK 抽取，2026-10-06）

## Xposed模块开发入门 `#教程`
- 手机端模块编写基础
- 详解：Xposed模块开发入门教程

### Xposed是什么
- Xposed是Android平台的Hook框架
- 通过修改Zygote进程实现全局Hook
- 无需修改APK即可改变APP行为
- 是持久化Hook的最主流方案

### 开发环境准备
- 手机必须Root并安装Xposed/LSPosed框架
- 电脑安装Android Studio
- 创建新项目，添加XposedApi依赖
- 编写模块代码并打包APK

### 最小模块代码示例
```
package com.example.xposedmodule;
public class MyModule implements IXposedHookLoadPackage {
public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
if (!lpparam.packageName.equals("目标包名")) return;
XposedHelpers.findAndHookMethod("目标类名", lpparam.classLoader, "目标方法名", new XC_MethodHook() {
protected void beforeHookedMethod(MethodHookParam param) {
XposedBridge.log("Hook成功！");
}
});
}
}
```

### 关键API说明
```
findAndHookMethod() → Hook指定类的指定方法
beforeHookedMethod() → 在原方法执行前插入逻辑
afterHookedMethod() → 在原方法执行后处理结果
setResult() → 直接设置返回值，跳过原方法
XposedBridge.log() → 输出日志到Xposed日志
```

### 手机端调试方法
- LSPosed管理器 → 日志页面查看输出
- 使用MT管理器查看/data/adb/lspd/log.log
- 配合Android Studio无线调试
- 用Toast弹出调试信息
> 提示：Xposed模块开发是Android逆向的进阶技能，先从Hook简单方法开始练手。

## Magisk+LSPosed `#推荐`
- 当前最主流Root方案
- 详解：Magisk + LSPosed 安装配置

### Magisk是什么
- Magisk是Android的Root解决方案
- 通过修改boot.img实现无系统修改Root
- 支持Magisk模块扩展功能
- 可以隐藏Root状态（MagiskHide）

### LSPosed是什么
- LSPosed是Xposed框架的Magisk模块替代品
- 基于Riru/Zygisk注入Zygote
- 相比传统Xposed更稳定、兼容性更好
- 支持Android 8-14

### 安装步骤
- 解锁Bootloader（会清除数据！）
- 刷入第三方Recovery（如TWRP）
- 通过Recovery刷入Magisk.zip
- 开机后安装Magisk App
- Magisk模块页面安装LSPosed
- 重启后在桌面找到LSPosed管理器

### 使用LSPosed
- 打开LSPosed管理器
- 进入"模块"页面启用你的Xposed模块
- 进入"作用域"勾选目标APP
- 强制停止目标APP后重新打开
- Hook即生效

### 常见问题
- Zygisk和Riru二选一，推荐Zygisk
- 部分银行APP检测到Magisk需配置DenyList
- Android 12+需要特定版本Magisk
- LSPosed模块需签名才能安装
> 提示：Magisk+LSPosed是目前最推荐的Root+Hook方案，稳定性远超传统Xposed。

## 太极·阳 `#免刷机`
- 免Root使用Xposed模块
- 详解：太极·阳 使用教程

### 太极是什么
- 太极是国产Xposed框架替代品
- 无需Root即可使用Xposed模块
- 通过应用级注入实现Hook
- 分为"太极·阴"（免Root）和"太极·阳"（需Root）

### 太极·阴 vs 太极·阳
- 太极·阴：免Root，但只能Hook普通APP
- 太极·阳：需Root，可以Hook系统APP
- 太极·阳兼容性更好，支持更多模块
- 推荐有Root条件的用太极·阳

### 使用步骤
- 安装太极APP
- 在太极中"创建应用"选择目标APP
- 太极会重新打包目标APP
- 安装太极版APP
- 在太极中安装并启用Xposed模块
- 打开太极版APP，Hook生效

### 优缺点
- 优点：无需刷机，适合不想折腾的用户
- 优点：对系统无侵入性
- 缺点：每次APP更新需重新创建
- 缺点：部分模块可能不兼容
- 缺点：无法Hook系统级功能
> 提示：太极适合不想刷机的用户，但有Root条件建议直接用LSPosed更稳定。

## 应用转生 `#免Root`
- 应用级Hook框架
- 详解：应用转生 使用教程

### 应用转生是什么
- 应用转生是一款国产应用级Hook工具
- 无需Root即可Hook目标APP
- 原理：修改APP的Dex插入Hook代码
- 支持部分Xposed模块功能

### 使用步骤
- 安装应用转生APP
- 点击"+"选择要Hook的目标APP
- 应用转生会重新编译目标APP
- 安装转生版APP（需卸载原版）
- 在应用转生中启用要使用的模块
- 打开转生版APP，Hook生效

### 支持模块
- 部分Xposed模块可以直接使用
- 应用转生有自己的模块生态
- 模块需在应用转生中单独安装
- 不支持需要系统级权限的模块

### 优缺点
- 优点：完全免Root
- 优点：操作简单，适合新手
- 缺点：每次APP更新需重新转生
- 缺点：兼容性不如LSPosed
- 缺点：部分高级功能不支持
> 提示：应用转生是太极的类似产品，两者选一个用即可，都不需要刷机。

## 反射大师 `#免Root`
- 免Root内存Hook神器
- 详解：反射大师 使用教程

### 反射大师是什么
- 反射大师是一款免Root的Android Hook工具
- 通过Java反射机制修改运行时内存
- 无需修改APK文件
- 支持方法Hook、字段修改、界面分析

### 核心功能
- 方法拦截：Hook任意Java方法返回值
- 字段修改：修改类中变量的值
- 布局分析：查看当前界面的View树
- Activity劫持：分析当前Activity信息

### 使用步骤
- 安装反射大师APP
- 打开反射大师，从列表选择目标APP
- 启动目标APP（从反射大师内启动）
- 悬浮窗呼出反射大师控制面板
- "方法拦截"中搜索要Hook的方法
- 勾选并设置返回值
- 目标APP即时生效

### Hook实战示例
```
Hook isVip() 返回 true → 解锁VIP
Hook getAdFlag() 返回 false → 去广告
Hook getRemainingCount() 返回999 → 无限次
Hook getPrice() 返回 0.01 → 修改价格
```

### 优缺点
- 优点：完全免Root，任何手机都能用
- 优点：实时生效，无需重启
- 优点：操作简单，适合新手
- 缺点：APP重启后失效（需重新Hook）
- 缺点：只能Hook当前运行的进程
- 缺点：部分加固APP可能检测并闪退
> 提示：反射大师是新手入门的最佳工具，完全免Root且操作简单，强烈推荐先从这个开始练手！
