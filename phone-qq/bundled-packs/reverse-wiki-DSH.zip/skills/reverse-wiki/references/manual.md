# 工具手册
> 分类 `manual` · 6 条 · 来源：黑猫逆向工程百科（APK 抽取，2026-10-06）

## Jadx GUI/CLI指南 `#反编译`
- 手机jadx查看Java源码
- 详解：Jadx 使用完整指南

### 工具简介
- jadx是一款开源的DEX反编译工具
- 将classes.dex还原为近似Java代码
- 支持GUI图形界面和CLI命令行
- 准确率是目前所有工具中最高的

### 手机端使用
- 下载jadx手机版APK
- 打开APK选择要反编译的文件
- 自动解析并显示Java代码
- 支持搜索、跳转、导出

### 常用操作
- 搜索类名/方法名/字符串
- 查看方法调用关系
- 导出反编译后的Java文件
- 对比多版本APK差异

### 注意事项
- 反编译出的代码非100%原始代码
- 变量名可能被混淆为a/b/c
- 部分语法可能需要手动修正
- 加固APK需先脱壳再反编译
> 提示：jadx是逆向必备工具，手机版已经能满足日常分析需求。

## Frida命令行指南 `#Hook`
- Termux手机端运行
- 详解：Frida 命令行完全指南

### 常用命令
- frida-ps -U → 列出手机上所有进程
- frida -U -f 包名 → 启动APP并Hook
- frida -U 进程名 → 附加到运行中的进程
- frida -U -l script.js -f 包名 → 加载脚本Hook

### 参数说明
- -U：通过USB连接（手机端默认）
- -f：启动新进程
- -l：加载JS脚本
- --no-pause：启动后不暂停

### Termux中使用
- pkg install python
- pip install frida-tools
- frida-ps -U 查看进程
- 直接编写和运行脚本

### 常用脚本模板
- Hook Java方法并打印参数
- Hook Native函数并修改返回值
- 枚举所有已加载的类
- 打印所有方法的调用栈
> 提示：Frida命令行是逆向的核心技能，建议把常用命令做成快捷脚本。

## Charles抓包配置 `#PC`
- PC+手机联合抓包
- 详解：Charles 抓包配置指南

### 工具简介
- Charles是PC端专业抓包工具
- 支持HTTP/HTTPS代理
- 支持断点调试和请求篡改
- 支持Map Remote/Map Local

### 手机连接配置
- 手机和电脑在同一WiFi
- 手机WiFi设置代理为电脑IP:8888
- Charles安装SSL证书到手机
- 开始抓包

### 高级功能
- Breakpoints：拦截请求修改参数
- Map Remote：将请求映射到其他服务器
- Map Local：用本地文件替换响应
- Rewrite：自动重写请求/响应

### 常见问题
- Android 7+需将证书安装到系统目录
- 部分APP使用SSL Pinning需配合Frida
- 代理模式可能被APP检测
> 提示：Charles是PC端最强抓包工具，配合手机代理可以分析所有APP流量。

## IDA Pro基础操作 `#Native`
- so库逆向分析
- 详解：IDA Pro 基础操作指南

### 工具简介
- IDA Pro是最强大的反汇编工具
- 支持ARM/x86/MIPS等多种架构
- 支持静态分析和动态调试
- 是Native层分析的标配工具

### 基础操作
- 打开so文件自动分析
- 查看导出函数表
- 搜索字符串定位关键逻辑
- 反汇编代码添加注释
- 交叉引用追踪函数调用

### 常用快捷键
- G：跳转到指定地址
- N：重命名变量/函数
- X：查看交叉引用
- ;：添加注释
- Tab：切换伪代码/汇编

### 手机端替代方案
- IDA手机版（功能有限）
- MT管理器提取so后传到PC分析
- 用Frida Hook替代静态分析
- 用Ghidra免费替代IDA
> 提示：IDA Pro学习曲线陡峭，建议从简单的so开始练习。

## ADB常用命令速查 `#调试`
- 无线ADB手机调试
- 详解：ADB 常用命令速查表

### 设备连接
- adb devices → 列出连接的设备
- adb connect IP:5555 → 无线连接
- adb disconnect → 断开连接
- adb kill-server → 重启ADB服务

### 文件操作
- adb push 本地 远程 → 上传文件
- adb pull 远程 本地 → 下载文件
- adb shell ls → 列出目录
- adb shell cat → 查看文件内容

### 应用管理
- adb install xxx.apk → 安装APK
- adb uninstall 包名 → 卸载应用
- adb shell pm list packages → 列出所有包
- adb shell am start -n 包名/Activity → 启动应用

### 调试相关
- adb logcat → 查看日志
- adb shell dumpsys → 查看系统信息
- adb shell ps → 查看进程
- adb shell top → 查看CPU/内存
> 提示：ADB是Android调试的基础，掌握常用命令可以大幅提升效率。

## Apktool反编译回编 `#必备`
- MT管理器集成apktool
- 详解：Apktool 反编译/回编指南

### 工具简介
- Apktool是开源APK反编译工具
- 反编译资源文件（xml、arsc）
- 反编译smali代码
- 支持修改后重新打包

### 常用命令
- apktool d xxx.apk → 反编译APK
- apktool b 目录 → 重新打包
- apktool d -f xxx.apk → 强制覆盖
- apktool b -o new.apk 目录 → 指定输出

### 手机端替代
- MT管理器内置apktool功能
- NP管理器支持反编译回编
- 开发者助手辅助分析
- 无需PC即可完成大部分操作

### 注意事项
- 反编译后需重新签名
- framework文件缺失可能导致反编译失败
- 部分资源可能无法完美还原
- 建议保留原始APK备份
> 提示：Apktool是PC端工具，但手机端用MT管理器已经可以替代90%的功能。
