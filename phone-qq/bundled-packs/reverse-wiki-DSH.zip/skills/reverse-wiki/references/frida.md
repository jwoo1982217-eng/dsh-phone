# Frida教程
> 分类 `frida` · 4 条 · 来源：黑猫逆向工程百科（APK 抽取，2026-10-06）

## Frida环境搭建 `#入门`
- Termux/手机端安装
- 详解：Frida手机端环境搭建

### 安装方式
- Termux安装：pkg install frida-tools
- Magisk模块：安装Frida-Server模块
- 手动推送：adb push frida-server /data/local/tmp

### 手机端运行步骤
- 确保设备已Root（Magisk/SU）
- 下载对应架构的frida-server
- adb push到/data/local/tmp并chmod 755
- 执行./frida-server &后台运行
- 另开终端用frida-ps -U测试连接

### Termux免PC方案
- Termux安装Python：pkg install python
- pip install frida-tools
- 手机直接运行frida命令无需电脑
- 配合QPython或Pydroid也可

### 常见问题
- frida-server版本需与客户端一致
- Android 12+需关闭SELinux或 MagiskHide
- 部分ROM需关闭内核调试限制
> 提示：推荐用Magisk模块方式安装Frida-Server，开机自动启动最省心。

## Hook Java层方法 `#核心`
- 手机端直接Hook
- 详解：Frida Hook Java层方法

### 基本语法
```
Java.perform(function() { ... }) → 进入Java上下文
Java.use("类名") → 获取目标类
类名.方法名.implementation = function() { ... } → 替换方法实现
```

### Hook单个方法
```
Java.perform(function() {
var Target = Java.use("com.xxx.TargetClass");
Target.targetMethod.implementation = function() {
console.log("Hooked!");
return true;
};
});
```

### 打印参数和返回值
```
Target.method.implementation = function(arg1, arg2) {
console.log("参数：", arg1, arg2);
var result = this.method(arg1, arg2);
console.log("返回值：", result);
return result;
};
```

### Hook构造函数
```
Java.use("类名").$init.implementation = function() { ... }
构造函数Hook用于追踪对象创建
常用于分析对象初始化流程
```
> 提示：Java层Hook是Frida最常用的功能，掌握后可以实现大部分逆向需求。

## Hook重载与内部类 `#进阶`
- overload/inner class
- 详解：Frida Hook重载与内部类

### Hook重载方法
```
重载方法同名但参数不同
Java.use("类").method.overload("参数类型1", "参数类型2")
如：method.overload("java.lang.String", "int")
参数类型需用完整类名
```

### Hook内部类
- 内部类类名格式：外部类$内部类
- 如：com.xxx.MainActivity$InnerClass
- Java.use("com.xxx.MainActivity$InnerClass")
- 注意$符号需要用引号包裹

### 匿名内部类
- 匿名内部类类名带数字：外部类$1、外部类$2
- 按顺序尝试Hook
- 或者用enumerateLoadedClasses遍历所有类
> 提示：重载和内部类是Frida Hook的进阶技巧，遇到同名方法时必须指定参数类型。

## Hook Native层方法 `#Native`
- 拦截so库函数
- 详解：Frida Hook Native层方法

### Native Hook基本语法
```
Interceptor.attach(address, { onEnter: ..., onLeave: ... })
Module.findExportByName("模块名", "函数名") → 获取函数地址
Module.findBaseAddress("模块名") → 获取模块基址
```

### Hook so导出函数
```
var addr = Module.findExportByName("libtarget.so", "target_func");
Interceptor.attach(addr, {
onEnter: function(args) {
console.log("参数：", args[0], args[1]);
},
onLeave: function(retval) {
console.log("返回值：", retval);
}
});
```

### Hook JNI函数
- JNI函数在so中导出，名称有规律
- Java_com_xxx_ClassName_methodName
- 直接用findExportByName查找即可Hook

### 内存读写
```
Memory.readUtf8String(ptr) → 读取字符串
Memory.readByteArray(ptr, length) → 读取字节数组
Memory.writeUtf8String(ptr, "文本") → 写入字符串
```
> 提示：Native层Hook需要了解ARM汇编基础，建议先掌握Java Hook再深入Native。
