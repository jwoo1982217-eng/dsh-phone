# 逆向关键词
> 分类 `keyword` · 13 条 · 来源：黑猫逆向工程百科（APK 抽取，2026-10-06）

## VIP/会员关键词 `#破解`
- isVip / isPremium / isMember
- 详解：VIP会员破解：原理与实操

### isVip 是什么意思
- isVip 是APP中判断用户是否为VIP的方法名
- 返回 true 表示是VIP，返回 false 表示不是
- 类似方法：isPremium() / isMember() / isPro() / checkVip()
- 这些方法通常在 UserManager / UserInfo / Account 类中

### 完整代码示例
```
原始代码（反编译后看到的）：
public boolean isVip() {
return this.vipStatus == 1;
}
或者：
public boolean isVip() {
return serverCheckVip(); // 服务端校验（更难）
}
```

### 方案A：改smali（永久修改APK）
- MT管理器打开APK → DEX编辑器
- 搜索 "isVip" 找到对应方法
- 查看smali代码，找到 return 语句
- 将 "const/4 v0, 0x0" 改为 "const/4 v0, 0x1"
- 保存并重新签名安装

### 方案B：Frida Hook（动态修改）
```
Java.perform(function() {
var UserClass = Java.use("com.xxx.UserManager");
UserClass.isVip.implementation = function() {
console.log("Hook isVip!");
return true;  // 强制返回VIP
};
});
```

### 方案C：反射大师（免Root）
- 打开反射大师，选择目标APP
- 在"方法拦截"中搜索 isVip
- 勾选该方法并设置返回值为 true
- 启动APP，即可生效
- 无需修改APK，重启后失效

### 进阶：服务端校验怎么办
- 如果isVip内部调用了服务端接口，仅改本地无效
- 需要配合抓包修改服务器返回数据
- 或者Hook网络请求函数强制返回VIP响应
- Hook OkHttp / HttpURLConnection 拦截响应体

### 更多VIP相关关键词
- isVip / isPremium / isMember
- checkVip / checkVipStatus / getVipType / getUserLevel
- getVipExpireTime / getVipEndDate
- canUseVipFeature / hasVipPermission
> 提示：建议先用反射大师或Frida Hook测试，确认修改有效后再改smali永久固化。

## 登录认证关键词 `#认证`
- login / token / sign / Token
- 详解：登录认证体系：原理与破解

### 关键词含义
```
login() / doLogin() → 发起登录请求的方法
token / accessToken → 服务器返回的身份凭证字符串
sign / signature → 请求参数的加密签名，防篡改
isLogin() / checkLogin() → 检查本地是否已登录
session / sessionId → 会话标识，维持登录状态
```

### Token机制详解
- 登录成功后服务器返回一串随机字符串Token
- APP把Token存在本地（SharedPreferences/数据库）
- 每次请求携带Token证明身份
- Token过期后需重新登录获取

### sign签名是什么
- sign是对请求参数的加密签名
- 防止请求被篡改的校验机制
- 通常用MD5/SHA1/HMAC等算法生成
- 逆向目标：找到签名算法并还原

### 修改方案A：跳过登录
```
Hook isLogin() 强制返回 true
Hook checkToken() 跳过过期检查
让APP认为"已经登录"直接进主界面
适用于仅前端限制的APP
```

### 修改方案B：Hook获取Token
```
Hook saveToken() 打印服务器返回的真实Token
Hook getToken() 返回固定有效的Token
用抓包工具复制Token到请求头中
用Postman测试接口是否可用
```

### 修改方案C：破解sign算法
- Hook getSign() 打印原始参数和生成的sign
- 对比多个请求的参数规律，还原算法
- 用Python重写sign算法验证正确性
- 构造任意参数的请求都能通过校验

### 更多关键词
- password / pwd / secret / secretKey
- authCode / verifyCode / captcha
- account / username / phone / email
- onLoginSuccess / onLoginFail / loginCallback
> 提示：登录模块是逆向的重要突破口，Hook login() 可以获取账号密码明文和服务器交互逻辑。

## 加密算法关键词 `#加密`
- encrypt / md5 / aes
- 详解：加密算法：定位与还原

### 关键词含义
```
encrypt() → 加密方法，将明文转为密文
decrypt() → 解密方法，将密文恢复为明文
md5 / sha1 / sha256 → 哈希算法，生成固定长度摘要
aes / des / rsa → 对称/非对称加密算法
base64 → Base64编码（不是加密，只是转换格式）
```

### 密钥怎么找
- 搜索 "key" / "secret" / "privateKey" / "iv"
- 检查 assets/ 目录下的 .json / .properties 配置文件
- 分析 so 库中的硬编码字符串
- Hook 加密函数打印密钥参数

### 修改方案A：Hook打印明文
```
Hook encrypt() 打印输入的明文和输出的密文
Hook decrypt() 直接获取解密后的明文数据
明文就是APP与服务器通信的真实内容
修改明文后重新加密发送伪造数据
```

### 修改方案B：算法还原
- Hook 加密函数获取算法名称（如AES/CBC/PKCS5Padding）
- 获取密钥(key)和初始向量(IV)参数
- 用Python的cryptography库重写相同算法
- 验证输出是否与APP生成的sign一致

### 修改方案C：跳过加密
```
Hook encrypt() 直接返回原始明文不加密
Hook checkSign() 跳过签名验证直接返回true
让APP的加密逻辑"短路"
适用于仅需本地功能、不需要联网的场景
```

### 常见组合套路
- AES加密 + Base64编码 → 传输数据
- MD5(参数拼接+密钥) → 生成sign签名
- RSA公钥加密 → 传输AES密钥（混合加密）
- HMAC-SHA256 → API请求认证
> 提示：大部分APP不会自己写加密，都是调用系统或开源库，找到库名称就能快速定位算法类型。

## 网络请求关键词 `#网络`
- baseUrl / host / url / api
- 详解：网络请求：API定位与分析

### 关键词含义
- baseUrl / BASE_URL → 服务器基础地址，如 https://api.xxx.com
- host / HOST → 域名，决定请求发往哪台服务器
- api / API → 接口路径前缀，如 /v1/user/login
- url / URL → 完整的请求地址
- request / response → HTTP请求和响应数据

### 找API的意义
- 找到所有数据接口可以脱离APP直接分析
- 用浏览器/Postman直接调用API测试
- 分析接口参数和返回数据结构
- 发现未授权接口或越权漏洞

### 手机端定位方法
- ProxyPin启动VPN抓包
- 打开APP操作所有功能触发请求
- 在ProxyPin中筛选域名和路径
- 复制关键接口URL和参数

### URL构造规律
- 格式：baseUrl + apiPath + queryParams
- 如 https://api.xxx.com/v1/user/info?id=123
- 版本号v1/v2代表不同协议版本
- 同模块接口路径前缀相同

### 修改方案
- Hook 请求发送函数修改URL参数
- Hook 响应接收函数修改返回数据
- 替换 baseUrl 指向本地代理服务器
- 拦截并重放请求构造任意参数

### 更多关键词
- path / endpoint / router / route
- port / protocol / scheme
- query / params / parameter / body
- header / User-Agent / Content-Type
- timeout / retry / connect / ssl
> 提示：找到baseUrl后，拼接各接口路径，就可以用浏览器或抓包工具直接测试API。

## 时间校验关键词 `#验证`
- expire / validTime / timestamp
- 详解：时间校验破解方法

### 关键词含义
```
expire / expired → 到期、过期
validTime → 有效时间段
timestamp → Unix时间戳（毫秒/秒）
getCurrentTime() → 获取当前系统时间
checkTrial() / isTrialExpired() → 检查试用期
```

### 时间校验原理
- APP获取当前时间（系统时间或服务器时间）
- 与VIP到期时间/试用开始时间做对比
- 如果 当前时间 > 到期时间，则功能失效
- 破解思路：让时间对比永远通过

### 方案A：改到期时间
- 搜索 expireTime 或 validTime 字段
- 找到设置到期时间的代码位置
- 将时间值改为 9999999999（遥远的未来）
- 或 Hook 获取到期时间的方法返回极大值

### 方案B：Hook时间获取
- Hook System.currentTimeMillis() 返回固定值
- 让APP永远"活"在试用期内
- 副作用：可能影响其他APP显示时间
- 适用于仅判断一次的APP

### 方案C：跳过校验
```
Hook checkTimeValid() 直接返回 true
Hook isTrialExpired() 直接返回 false
让时间校验逻辑直接"短路"
最简单粗暴的方案
```

### 更多关键词
- trial / trialPeriod / trialDays
- startTime / endTime / deadline
- remainingTime / leftTime / countdown
- firstLaunch / installDate / registerDate
> 提示：时间校验比VIP校验简单，通常改一个地方就能永久生效。

## 广告相关关键词 `#去广告`
- ad / ads / banner / AdView
- 详解：去广告关键词与方案

### 关键词含义
```
AdView / BannerView → 广告显示控件类
showAd() / loadAd() / displayAd() → 触发广告加载
onAdLoaded() / onAdShow() → 广告SDK回调
adUnitId / adId → 广告单元ID，用于区分广告位
AdsManager / AdHelper → 广告管理类
```

### 方案A：跳过广告加载
```
Hook loadAd() 方法，直接 return 不执行
Hook showAd() 方法，return空
广告SDK初始化失败就不显示
副作用：可能留下空白占位
```

### 方案B：跳过广告展示
- Hook onAdLoaded() 不显示直接return
- 修改广告显示条件为false
- 让广告逻辑走"加载失败"分支
- APP会认为网络不好加载失败

### 方案C：布局隐藏
- 用开发者助手查看广告View的ID
- 在smali中findViewById广告控件
- 设置广告控件visibility为GONE
- 广告控件隐藏且不占位

### 方案D：替换广告ID
- 找到广告SDK初始化传入的adUnitId
- 替换为无效的广告ID
- 广告SDK请求不到广告自然不显示
- 适用于穿山甲、优量汇等SDK

### 更多关键词
- interstitial / splash / reward / native
- mintegral / pangle / gdt / admob
- preloadAd / cacheAd / fetchAd
- adError / onAdFailed / adClosed
> 提示：去广告推荐先用Hook方案测试效果，确认无崩溃后再改smali永久固化。

## 签名验证关键词 `#签名`
- sign / verifySign / getSign
- 详解：签名验证：原理与绕过

### 关键词含义
```
sign / signature / getSign() → 请求签名算法
verifySign() / checkSign() → 签名验证方法
privateKey / secretKey → 签名使用的密钥
salt / nonce → 签名附加的随机值
timestamp → 签名时的时间戳（防重放）
```

### 签名机制原理
- APP将所有请求参数按规则拼接成字符串
- 用密钥对字符串做哈希（MD5/SHA/HMAC）
- 将哈希结果作为sign附在请求中发送
- 服务器用同样规则计算，对比sign是否一致

### 为什么签名重要
- 防止请求被篡改（改了参数sign就不对）
- 防止重放攻击（加入时间戳和随机数）
- 验证请求确实来自合法APP
- 逆向中还原sign是协议分析的核心

### 修改方案A：Hook打印sign
- Hook getSign() 打印原始参数和生成的sign
- 对比多个请求找出参数拼接规则
- 用不同参数请求对比sign变化
- 逐步还原完整算法

### 修改方案B：跳过签名校验
```
Hook verifySign() 直接返回 true
Hook checkSignature() 跳过验证
让APP认为所有签名都正确
适用于仅需本地功能的情况
```

### 修改方案C：重算签名
- Hook后获取密钥和算法参数
- 用Python/Java重写签名算法
- 构造任意参数的合法请求
- 实现自动化请求篡改
> 提示：签名算法还原是协议逆向的难点，但一旦破解就可以完全控制APP的所有网络请求。

## 支付相关关键词 `#支付`
- pay / purchase / orderId
- 详解：支付相关关键词：原理与破解

### 关键词含义
```
pay() / doPay() / purchase() → 发起支付
orderId / tradeNo → 订单号
paySuccess() / onPayResult() → 支付结果回调
getPrice() / getAmount() → 获取商品价格
sku / productId / goodsId → 商品标识
```

### 支付流程拆解
```
用户点击购买 → APP调用pay()方法
APP向服务器创建订单获取orderId
调起微信/支付宝/谷歌支付SDK
支付完成后回调onPayResult(result)
result=true则解锁对应功能
```

### 修改方案A：Hook支付结果
```
Hook onPayResult() 强制返回成功
Hook paySuccess() 直接执行解锁逻辑
让APP认为"支付已完成"
适用于仅前端校验的APP
```

### 修改方案B：修改价格
```
Hook getPrice() 返回 0 或 0.01元
Hook getAmount() 返回极小值
实际支付时会按修改后的金额
可尝试支付一分钱解锁全部
```

### 修改方案C：跳过支付流程
```
Hook pay() 直接跳转到支付成功回调
不调用微信/支付宝SDK
让逻辑直接走到 unlockFeature()
注意：服务端可能再次校验
```

### 服务端校验应对
- 如果服务器会查订单状态，仅改本地无效
- 需要构造真实订单号或Hook服务器响应
- 用Frida拦截支付回调修改result
- 复杂情况建议配合抓包分析

### 更多关键词
- billing / iap / inAppPurchase / recharge
- consume / acknowledge / verifyPurchase
- wallet / balance / coin / diamond / credit
- coupon / discount / promotion / freeTrial
> 提示：支付破解仅用于学习研究，切勿用于实际商业应用，涉及法律风险。

## 弹窗更新关键词 `#弹窗`
- checkUpdate / showDialog
- 详解：弹窗更新与限制关键词

### 关键词含义
```
checkUpdate() / isNeedUpdate() → 检查是否有新版本
showUpdateDialog() → 显示更新弹窗
forceUpdate / mustUpdate → 强制更新（不更新不能用）
downloadUrl / updateUrl → 更新包下载地址
versionCode / versionName → 版本号比较
```

### 弹窗类关键词
- showDialog / showPopup / showToast → 各种弹窗
- dismiss() / cancel() / hide() → 关闭弹窗
- DialogFragment / AlertDialog → 弹窗组件
- onBackPressed → 返回键拦截（弹窗不让关）

### 修改方案A：跳过更新检查
```
Hook checkUpdate() 直接返回"无需更新"
Hook isNeedUpdate() 返回 false
Hook showUpdateDialog() 直接return不执行
APP不再弹出更新提示
```

### 修改方案B：关闭弹窗拦截
```
Hook showDialog() 直接dismiss关闭
Hook onBackPressed 允许返回键关闭
Hook setCancelable(true) 让弹窗可取消
适用于开屏广告、评分弹窗等
```

### 修改方案C：修改版本号
- 修改versionCode为极大值（如99999）
- 服务器认为你是最新版不再推送更新
- AndroidManifest中修改android:versionCode
- 注意：部分APP会联网查最新版本

### 更多关键词
- rate / rating / comment / feedback
- guide / tutorial / firstRun / welcome
- announcement / notice / notification
- splash / launch / startup / boot
> 提示：弹窗关闭是最简单的逆向操作，Hook show方法直接return即可消灭大部分烦人弹窗。

## 设备限制关键词 `#限制`
- deviceId / count / limit
- 详解：设备/次数限制关键词

### 关键词含义
- deviceId / deviceToken / imei → 设备唯一标识
- uuid / guid / fingerprint → 设备指纹
- count / countDown / remaining → 剩余次数
- limit / max / quota → 上限/配额
- bindDevice / bindPhone → 设备绑定

### 次数限制破解
```
Hook getRemainingCount() 返回极大值
Hook getUsedCount() 始终返回0
Hook decreaseCount() 不执行减操作
让APP认为"一次都没用过"
```

### 设备绑定破解
```
Hook getDeviceId() 返回固定值
Hook getIMEI() 返回合法IMEI
多台设备用同一个deviceId伪装同一设备
适用于"仅限一台设备使用"的场景
```

### 设备指纹伪造
- 设备指纹由多个参数组合生成
- 包括IMEI、MAC、AndroidID、Build.SERIAL等
- Hook fingerprint生成函数，返回固定值
- 让所有设备生成相同的指纹

### 更多关键词
- macAddress / androidId / serialNumber
- imei / meid / simSerialNumber
- phoneNumber / subscriberId / networkOperator
- buildBoard / buildDevice / buildProduct
> 提示：次数限制最容易破解，改一个返回值就能无限使用；设备绑定需要伪造设备标识。

## Root检测关键词 `#检测`
- isRooted / checkRoot / su
- 详解：Root检测关键词：原理与绕过

### 关键词含义
- isRooted() / checkRoot() → 检测设备是否Root
- su / Superuser / Magisk → Root相关文件/应用
- rootCheck / rootDetect / rootVerify → Root检测方法
- SafetyNet / PlayIntegrity → Google完整性检测

### Root检测常见方式
- 检查 /system/bin/su 是否存在
- 检查 /data/adb/magisk 目录
- 尝试执行su命令看是否成功
- 检查已安装应用列表是否有Magisk
- 检查SELinux状态是否为Permissive

### 绕过方案A：MagiskHide
- Magisk设置 → 配置MagiskHide
- 勾选目标APP隐藏Root
- APP检测不到su和Magisk文件
- 最稳定可靠的方案

### 绕过方案B：Shamiko模块
- 安装Shamiko模块（Magisk模块）
- 自动隐藏所有Root痕迹
- 包括文件、进程、系统痕迹
- 比MagiskHide更彻底

### 绕过方案C：Hook检测函数
```
Hook isRooted() 强制返回 false
Hook checkSuExists() 返回文件不存在
Hook Runtime.exec("su") 抛出异常
适用于没有SafetyNet的APP
```

### Google SafetyNet绕过
- SafetyNet验证设备是否被篡改
- 需通过Magisk + Shamiko + 特定指纹
- 或使用Magisk的SafetyNet修复模块
- 部分银行/支付APP检测严格
> 提示：Root检测绕过推荐优先用MagiskHide/Shamiko，Hook检测函数作为备用方案。

## 反调试关键词 `#对抗`
- isDebuggable / ptrace
- 详解：反调试检测：原理与对抗

### 关键词含义
```
isDebuggable() → 检查APP是否处于调试模式
isDebuggerConnected() → 检查是否有调试器连接
ptrace / PtraceCheck → Linux进程追踪检测
fridaCheck / fridaDetect → 检测Frida注入
emulatorCheck / isEmulator → 检测模拟器
```

### 反调试常见手段
```
ptrace(PTRACE_TRACEME) 防止被其他进程调试
检查 /proc/self/status 中 TracerPid
循环检测isDebuggerConnected()
校验代码完整性（防篡改）
检测Frida的端口、线程、内存特征
```

### 对抗方案A：Hook检测函数
```
Hook isDebuggerConnected() 返回 false
Hook checkPtrace() 直接返回
Hook frida检测函数返回"未检测到"
让APP认为运行环境"干净"
```

### 对抗方案B：修改状态文件
- /proc/self/status 中 TracerPid 改为0
- 修改代码段的校验和绕过完整性检查
- 用Magisk模块隐藏Frida相关进程
- 需要Root权限操作内核数据

### 对抗方案C：使用反检测版本
- 使用Magisk的Frida-Server模块（自带隐藏）
- 使用objection的--no-root启动
- 配合MagiskHide隐藏调试痕迹
- 部分ROM自带反调试补丁
> 提示：反调试对抗是逆向高阶内容，新手遇到强反调试建议先绕开或找现成方案。

## 通用Hook关键词 `#工具`
- hook / reflect / dump
- 详解：通用Hook/工具关键词

### Hook相关关键词
```
hook / Hook → 拦截方法调用
intercept / before / after → 拦截前后处理
replace / override / implement → 替换方法实现
Java.use() / Java.perform() → Frida核心API
Module.findExportByName() → 查找Native函数
```

### 反射相关关键词
```
reflect / Reflection → Java反射机制
getDeclaredMethod() → 获取私有方法
setAccessible(true) → 突破访问权限
invoke() → 调用方法
Class.forName() → 动态加载类
```

### 通用逆向关键词
- dump / extract → 提取/导出
- patch / modify / edit → 修改
- inject / gadget → 注入
- trace / log / print → 追踪日志
- bypass / skip / jump → 绕过/跳过

### 常用搜索组合
- "return true" + "isVip" → 快速定位VIP校验
- "check" + "sign" → 定位签名验证
- "load" + "ad" → 定位广告加载
- "verify" + "license" → 定位许可证校验
- "get" + "token" → 定位Token获取
> 提示：掌握这些通用关键词，配合搜索组合技巧，可以快速定位APP中任意功能的实现位置。
