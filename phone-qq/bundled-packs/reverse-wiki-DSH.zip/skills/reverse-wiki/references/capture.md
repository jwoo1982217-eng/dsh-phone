# 抓包分析
> 分类 `capture` · 4 条 · 来源：黑猫逆向工程百科（APK 抽取，2026-10-06）

## HttpCanary(小黄鸟) `#推荐`
- 安卓抓包神器 需Root
- 详解：HttpCanary(小黄鸟)使用教程

### 工具简介
- HttpCanary是Android平台专业的抓包工具
- 支持HTTP/HTTPS/WebSocket协议
- 支持断点调试和请求篡改
- 需要Root或VPN模式

### 安装配置
- 下载安装HttpCanary APP
- 授予VPN权限（免Root模式）
- 或Root后安装系统证书
- 配置抓包规则（可选）

### 使用方法
- 启动HttpCanary，点击开始抓包
- 打开目标APP操作各种功能
- 回到HttpCanary查看抓到的请求
- 点击请求查看详情（请求头、参数、响应）

### 高级功能
- 断点：拦截请求修改后再发送
- 重放：重复发送某个请求
- 替换：替换请求参数或响应数据
- 脚本：编写JavaScript处理请求

### 常见问题
- Android 7+需将证书安装到系统信任区
- 部分APP使用证书绑定需配合Frida绕过
- 抓包过多时注意清理缓存
- 部分银行APP检测到抓包会拒绝连接
> 提示：HttpCanary功能强大，是移动端抓包的首选工具。

## ProxyPin `#免Root`
- VPN模式免Root抓包
- 详解：ProxyPin使用教程

### 工具简介
- ProxyPin是一款免Root的抓包工具
- 通过VPN模式拦截APP网络请求
- 无需安装系统证书
- 支持HTTP/HTTPS抓包

### 使用步骤
- 安装ProxyPin APP
- 打开APP授予VPN权限
- 启动抓包服务
- 打开目标APP操作
- 回到ProxyPin查看请求列表

### 优点
- 完全免Root，任何手机可用
- 无需安装系统证书
- VPN模式不易被检测
- 操作简单适合新手

### 局限性
- VPN模式只能抓本机流量
- 部分APP检测VPN会拒绝连接
- 功能比HttpCanary简单
- 不支持断点调试
> 提示：ProxyPin适合不想Root的用户快速抓包分析。

## Reqable手机版 `#免Root`
- 专业级手机抓包工具
- 详解：Reqable手机版使用教程

### 工具简介
- Reqable是一款专业的HTTP开发调试工具
- 手机版支持抓包、API调试、脚本处理
- 界面美观，功能全面
- 支持VPN模式免Root抓包

### 主要功能
- 抓包分析：拦截查看HTTP/HTTPS请求
- API调试：构造和发送HTTP请求
- 脚本处理：用Python脚本处理请求
- 历史记录：保存和重放请求

### 使用方法
- 安装Reqable APP
- 配置VPN模式或Root证书
- 启动抓包
- 操作目标APP
- 查看分析请求数据
> 提示：Reqable是新一代抓包工具，界面现代功能强大，值得一试。

## 证书安装教程 `#必看`
- 系统证书+VPN模式配置
- 详解：HTTPS证书安装完整教程

### 为什么需要证书
- HTTPS流量是加密的，无法直接查看
- 安装证书后抓包工具可以解密HTTPS
- 证书相当于让抓包工具成为"中间人"

### 证书类型
- 用户证书：安装到用户目录，Android 7+默认不信任
- 系统证书：安装到系统目录，所有APP都信任
- Root用户：可以将用户证书移动到系统目录
- 非Root用户：只能用VPN模式绕过

### Root用户安装系统证书
- 抓包工具导出证书文件（.crt/.pem）
- 将证书重命名为哈希值.0格式
- 用MT管理器复制到 /system/etc/security/cacerts/
- 重启手机生效

### Magisk模块方式
- 安装Magisk的"Always Trust User Certs"模块
- 自动让所有APP信任用户证书
- 最简单可靠的方案
- 不需要手动移动证书

### 非Root用户方案
- 使用ProxyPin等VPN模式抓包工具
- VPN模式不需要系统证书
- 或安装平行空间/多开软件配合
- 部分APP在平行空间中不检测证书
> 提示：证书安装是抓包的关键步骤，Root用户推荐用Magisk模块方式最简单。
