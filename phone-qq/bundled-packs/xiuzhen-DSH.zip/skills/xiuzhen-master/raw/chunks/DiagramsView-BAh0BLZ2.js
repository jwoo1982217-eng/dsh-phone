import{A as e,F as t,R as n,T as r,c as i,h as a,i as o,k as s,v as c,x as l}from"./index-uyThFnHT.js";var u=[{title:`ReAct 天行诀`,sub:`推理-行动-观察循环 · Agent筑基功法`,svg:`<svg viewBox="0 0 360 210" class="diagram-svg">
     <defs><marker id="arr1" markerWidth="8" markerHeight="6" refX="8" refY="3" orient="auto"><path d="M0,0 L8,3 L0,6" fill="#5ce1e6"/></marker></defs>
     <rect x="30" y="30" width="90" height="50" rx="8" fill="rgba(212,175,55,.15)" stroke="#d4af37" stroke-width="1.5"/>
     <text x="75" y="50" text-anchor="middle" fill="#d4af37" font-size="13" font-family="serif">Thought</text>
     <text x="75" y="65" text-anchor="middle" fill="#a09680" font-size="9">推理思考</text>
     <rect x="135" y="30" width="90" height="50" rx="8" fill="rgba(92,225,230,.15)" stroke="#5ce1e6" stroke-width="1.5"/>
     <text x="180" y="50" text-anchor="middle" fill="#5ce1e6" font-size="13" font-family="serif">Action</text>
     <text x="180" y="65" text-anchor="middle" fill="#a09680" font-size="9">调用工具</text>
     <rect x="240" y="30" width="90" height="50" rx="8" fill="rgba(46,204,113,.15)" stroke="#2ecc71" stroke-width="1.5"/>
     <text x="285" y="50" text-anchor="middle" fill="#2ecc71" font-size="13" font-family="serif">Answer</text>
     <text x="285" y="65" text-anchor="middle" fill="#a09680" font-size="9">最终答案</text>
     <rect x="105" y="130" width="150" height="50" rx="8" fill="rgba(155,89,182,.15)" stroke="#9b59b6" stroke-width="1.5"/>
     <text x="180" y="150" text-anchor="middle" fill="#9b59b6" font-size="13" font-family="serif">Observation</text>
     <text x="180" y="165" text-anchor="middle" fill="#a09680" font-size="9">观察结果</text>
     <line x1="120" y1="55" x2="135" y2="55" stroke="#5ce1e6" stroke-width="1.5" marker-end="url(#arr1)"/>
     <line x1="180" y1="80" x2="180" y2="126" stroke="#5ce1e6" stroke-width="1.5" marker-end="url(#arr1)"/>
     <line x1="225" y1="55" x2="240" y2="55" stroke="#2ecc71" stroke-width="1.5" marker-end="url(#arr1)"/>
     <line x1="238" y1="168" x2="285" y2="168" stroke="#5ce1e6" stroke-width="1.5"/>
     <line x1="285" y1="168" x2="285" y2="84" stroke="#5ce1e6" stroke-width="1.5" marker-end="url(#arr1)"/>
     <text x="262" y="162" text-anchor="middle" fill="#a09680" font-size="8">再推理</text>
     <text x="180" y="206" text-anchor="middle" fill="#a09680" font-size="10">循环直到信息足够 → 输出答案</text>
   `,desc:`Thought推理需要什么→Action调工具获取→Observation拿到结果→循环。所有AI Agent的理论基石，适合需要外部知识的开放问题。`},{title:`Plan-and-Execute 先知策`,sub:`先规划再执行 · 复杂任务之选`,svg:`<svg viewBox="0 0 360 200" class="diagram-svg">
     <defs><marker id="arr2" markerWidth="8" markerHeight="6" refX="8" refY="3" orient="auto"><path d="M0,0 L8,3 L0,6" fill="#d4af37"/></marker></defs>
     <rect x="125" y="10" width="110" height="40" rx="8" fill="rgba(212,175,55,.15)" stroke="#d4af37" stroke-width="1.5"/>
     <text x="180" y="35" text-anchor="middle" fill="#d4af37" font-size="13" font-family="serif">Planner 规划器</text>
     <line x1="180" y1="50" x2="180" y2="70" stroke="#d4af37" stroke-width="1.5" marker-end="url(#arr2)"/>
     <rect x="30" y="70" width="90" height="35" rx="6" fill="rgba(92,225,230,.1)" stroke="#5ce1e6" stroke-width="1"/>
     <text x="75" y="92" text-anchor="middle" fill="#5ce1e6" font-size="11">任务1</text>
     <rect x="135" y="70" width="90" height="35" rx="6" fill="rgba(92,225,230,.1)" stroke="#5ce1e6" stroke-width="1"/>
     <text x="180" y="92" text-anchor="middle" fill="#5ce1e6" font-size="11">任务2</text>
     <rect x="240" y="70" width="90" height="35" rx="6" fill="rgba(92,225,230,.1)" stroke="#5ce1e6" stroke-width="1"/>
     <text x="285" y="92" text-anchor="middle" fill="#5ce1e6" font-size="11">任务N</text>
     <line x1="75" y1="105" x2="75" y2="130" stroke="#d4af37" stroke-width="1" marker-end="url(#arr2)"/>
     <line x1="180" y1="105" x2="180" y2="130" stroke="#d4af37" stroke-width="1" marker-end="url(#arr2)"/>
     <line x1="285" y1="105" x2="285" y2="130" stroke="#d4af37" stroke-width="1" marker-end="url(#arr2)"/>
     <rect x="30" y="130" width="90" height="35" rx="6" fill="rgba(46,204,113,.1)" stroke="#2ecc71" stroke-width="1"/>
     <text x="75" y="152" text-anchor="middle" fill="#2ecc71" font-size="11">执行+验证</text>
     <rect x="135" y="130" width="90" height="35" rx="6" fill="rgba(46,204,113,.1)" stroke="#2ecc71" stroke-width="1"/>
     <text x="180" y="152" text-anchor="middle" fill="#2ecc71" font-size="11">执行+验证</text>
     <rect x="240" y="130" width="90" height="35" rx="6" fill="rgba(46,204,113,.1)" stroke="#2ecc71" stroke-width="1"/>
     <text x="285" y="152" text-anchor="middle" fill="#2ecc71" font-size="11">执行+验证</text>
     <line x1="180" y1="165" x2="180" y2="180" stroke="#d4af37" stroke-width="1.5" marker-end="url(#arr2)"/>
     <rect x="29.9" y="180" width="300.0" height="16" rx="4" fill="rgba(155,89,182,.15)" stroke="#9b59b6" stroke-width="1"/>
     <text x="180" y="192" text-anchor="middle" fill="#9b59b6" font-size="10">汇总输出</text>
   </svg>`,desc:`规划器先拆任务图，执行器按依赖逐项完成，每步验证，错误回滚。适合竞品报告、研究综述等复杂多步任务。`},{title:`蜂巢炼阵 · 蜂群调度`,sub:`主灵蜂后+工蜂+侦察蜂`,svg:`<svg viewBox="0 0 360 200" class="diagram-svg">
     <defs><marker id="arr3" markerWidth="8" markerHeight="6" refX="8" refY="3" orient="auto"><path d="M0,0 L8,3 L0,6" fill="#e67e22"/></marker></defs>
     <polygon points="180,15 210,55 150,55" fill="rgba(212,175,55,.2)" stroke="#d4af37" stroke-width="1.5"/>
     <text x="180" y="42" text-anchor="middle" fill="#d4af37" font-size="12" font-family="serif">蜂后主灵</text>
     <text x="180" y="55" text-anchor="middle" fill="#a09680" font-size="8">只调度不干活</text>
     <line x1="160" y1="55" x2="80" y2="85" stroke="#e67e22" stroke-width="1.2" marker-end="url(#arr3)"/>
     <line x1="180" y1="55" x2="180" y2="85" stroke="#e67e22" stroke-width="1.2" marker-end="url(#arr3)"/>
     <line x1="200" y1="55" x2="280" y2="85" stroke="#e67e22" stroke-width="1.2" marker-end="url(#arr3)"/>
     <rect x="30" y="85" width="100" height="40" rx="8" fill="rgba(92,225,230,.12)" stroke="#5ce1e6" stroke-width="1.2"/>
     <text x="80" y="105" text-anchor="middle" fill="#5ce1e6" font-size="11" font-family="serif">分诊蜂</text>
     <text x="80" y="118" text-anchor="middle" fill="#a09680" font-size="8">免费七题判定</text>
     <rect x="130" y="85" width="100" height="40" rx="8" fill="rgba(155,89,182,.12)" stroke="#9b59b6" stroke-width="1.2"/>
     <text x="180" y="105" text-anchor="middle" fill="#9b59b6" font-size="11" font-family="serif">工蜂群</text>
     <text x="180" y="118" text-anchor="middle" fill="#a09680" font-size="8">各管一摊干活</text>
     <rect x="230" y="85" width="100" height="40" rx="8" fill="rgba(46,204,113,.12)" stroke="#2ecc71" stroke-width="1.2"/>
     <text x="280" y="105" text-anchor="middle" fill="#2ecc71" font-size="11" font-family="serif">侦察蜂</text>
     <text x="280" y="118" text-anchor="middle" fill="#a09680" font-size="8">单程任务即卸</text>
     <line x1="80" y1="125" x2="80" y2="150" stroke="#e67e22" stroke-width="1" marker-end="url(#arr3)"/>
     <line x1="180" y1="125" x2="180" y2="150" stroke="#e67e22" stroke-width="1" marker-end="url(#arr3)"/>
     <line x1="280" y1="125" x2="280" y2="150" stroke="#e67e22" stroke-width="1" marker-end="url(#arr3)"/>
     <rect x="30" y="150" width="300" height="35" rx="8" fill="rgba(230,126,34,.1)" stroke="#e67e22" stroke-width="1.2"/>
     <text x="180" y="172" text-anchor="middle" fill="#e67e22" font-size="11" font-family="serif">心跳守护 · 定时巡场 · 有活干活没活报平安</text>
     <text x="180" y="195" text-anchor="middle" fill="#a09680" font-size="9">confidence低才转主脑，token省一半</text>
   </svg>`,desc:`主灵只调度，分诊蜂免费判定，工蜂带任务书上岗，侦察蜂单程即卸。蜂群协同，效率提升4.5倍。`},{title:`类脑四层架构`,sub:`感知-记忆-决策-表达 · 让角色活起来`,svg:`<svg viewBox="0 0 300 284" class="diagram-svg">
     <defs><marker id="arr4" markerWidth="8" markerHeight="6" refX="8" refY="3" orient="auto"><path d="M0,0 L8,3 L0,6" fill="#8e44ad"/></marker></defs>
     <rect x="60" y="6" width="70" height="28" rx="8" fill="rgba(92,225,230,.12)" stroke="#5ce1e6" stroke-width="1.3"/>
     <text x="95" y="25" text-anchor="middle" fill="#5ce1e6" font-size="13" font-family="serif">感知层</text>
     <line x1="95" y1="34" x2="95" y2="46" stroke="#8e44ad" stroke-width="1.2" marker-end="url(#arr4)"/>
     <rect x="25" y="48" width="250" height="30" rx="6.7" fill="rgba(0,0,0,.2)" stroke="#2d3548"/>
     <text x="150" y="68" text-anchor="middle" fill="#a09680" font-size="11">情绪识别 · 意图解析 · 过滤无关</text>
     <line x1="95" y1="78" x2="95" y2="90" stroke="#8e44ad" stroke-width="1.2" marker-end="url(#arr4)"/>
     <rect x="60" y="92" width="70" height="28" rx="8" fill="rgba(212,175,55,.12)" stroke="#d4af37" stroke-width="1.3"/>
     <text x="95" y="111" text-anchor="middle" fill="#d4af37" font-size="13" font-family="serif">记忆层</text>
     <line x1="95" y1="120" x2="95" y2="132" stroke="#8e44ad" stroke-width="1.2" marker-end="url(#arr4)"/>
     <rect x="25" y="134" width="250" height="30" rx="6.7" fill="rgba(0,0,0,.2)" stroke="#2d3548"/>
     <text x="150" y="154" text-anchor="middle" fill="#a09680" font-size="11">工作/短期/长期/情景/语义/程序/核心</text>
     <line x1="95" y1="164" x2="95" y2="176" stroke="#8e44ad" stroke-width="1.2" marker-end="url(#arr4)"/>
     <rect x="60" y="178" width="70" height="28" rx="8" fill="rgba(155,89,182,.12)" stroke="#9b59b6" stroke-width="1.3"/>
     <text x="95" y="197" text-anchor="middle" fill="#9b59b6" font-size="13" font-family="serif">决策层</text>
     <line x1="95" y1="206" x2="95" y2="218" stroke="#8e44ad" stroke-width="1.2" marker-end="url(#arr4)"/>
     <rect x="25" y="220" width="250" height="30" rx="6.7" fill="rgba(0,0,0,.2)" stroke="#2d3548"/>
     <text x="150" y="240" text-anchor="middle" fill="#a09680" font-size="11">推理规划 · 情绪调节 · 一致性校验</text>
     <line x1="95" y1="250" x2="95" y2="258" stroke="#8e44ad" stroke-width="1.2" marker-end="url(#arr4)"/>
     <rect x="60" y="260" width="70" height="24" rx="8" fill="rgba(46,204,113,.12)" stroke="#2ecc71" stroke-width="1.3"/>
     <text x="95" y="277" text-anchor="middle" fill="#2ecc71" font-size="13" font-family="serif">表达层</text>
   </svg>`,desc:`模拟人脑分层认知，外部记忆解决失忆问题，内部思考不外露。角色能记住三个月前的细节，人格稳定但有生命力。`}],d={class:`page-section`,style:{"padding-top":`96px`}},f={class:`diagram-grid`},p={class:`diagram-sub`},m=[`innerHTML`],h={class:`diagram-desc`},g=r({__name:`DiagramsView`,setup(r){function g(){i.diagramsViewed=Math.min((i.diagramsViewed||0)+1,u.length),o()}return(r,i)=>(s(),l(`section`,d,[i[0]||=c(`div`,{class:`section-title`},[c(`h2`,{class:`xiaowei`},`Agent 阵图`),c(`p`,null,`核心架构阵图 · SVG 手绘 · 点阵图入阵`),c(`div`,{class:`divider`})],-1),c(`div`,f,[(s(!0),l(a,null,e(t(u),e=>(s(),l(`div`,{key:e.title,class:`diagram-card`,onClick:g},[c(`h3`,null,n(e.title),1),c(`div`,p,n(e.sub),1),c(`div`,{class:`diagram-svg-wrap`,innerHTML:e.svg},null,8,m),c(`p`,h,n(e.desc),1)]))),128))])]))}});export{g as default};