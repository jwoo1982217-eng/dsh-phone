# 百炼成仙 · 修真技能包

> 来源：https://challenge.dandanllab.top/
> 打包时间：2026-10-06
> 版本：1.1.0（合并第三方通用AI学习包 v1.1）

将百炼成仙知识库八大藏全部封装为可执行技能包，含结构化数据、原版镜像、模板资源。v1.1 新增第三方通用学习包扩展（9技能+5提示卡+10模板+24实践法+15验收场景）。

## 目录结构

```
xiuzhen-skills/
├── SKILL.md                    # 主技能入口：修真总纲（路由+核心公理）
├── README.md                   # 本文件
├── skills/                     # 八大藏子技能
│   ├── gongfa/                 # 第一藏·功法秘籍阁（53张功法卡）
│   │   ├── SKILL.md
│   │   └── data/data_gongfa.json
│   ├── realms/                 # 第二藏·修真境界图谱（九大境界）
│   │   ├── SKILL.md
│   │   └── data/data_realms.json
│   ├── roadmap/                # 第三藏·修炼路引（九阶段任务书）
│   │   ├── SKILL.md
│   │   └── data/data_roadmap.json
│   ├── worldbook/              # 第四藏·世界书阁（四篇设定百科）
│   │   ├── SKILL.md
│   │   └── data/data_worldbook.json
│   ├── artifacts/              # 第五藏·法宝利器库（18件法器）
│   │   ├── SKILL.md
│   │   └── data/data_artifacts.json
│   ├── dialogue/               # 第六藏·师徒问答（五话题）
│   │   ├── SKILL.md
│   │   └── data/data_dialogues.json
│   ├── diagrams/               # 第八藏·Agent阵图（4张SVG）
│   │   ├── SKILL.md
│   │   └── data/data_diagrams.json
│   └── library/                # 第七藏·藏书阁（94章+启蒙典+题库话本）
│       ├── SKILL.md
│       └── data/               # 6个原始JS分片
│           ├── books.js
│           ├── books_vol2.js
│           ├── books_vol3.js
│           ├── books_vol4.js
│           ├── books_vol5.js
│           └── books_story.js
├── templates/
│   ├── TEMPLATES.md            # 10套可直接套用的模板（八大藏体系）
│   └── THIRD-PARTY-ESSENTIALS.md  # 第三方包精华提炼（24实践法+15验收场景+互补关系）
├── scripts/                    # （预留）可执行脚本
├── extensions/                 # 第三方扩展包（原封不动）
│   └── third-party-v1.1/      # Agent百炼成仙·通用AI学习包 v1.1.0（41文件）
│       ├── 通用AI学习.md        # 完整单文件方法手册（50KB）
│       ├── 先读我.md / 开始使用.txt / 补充说明.md
│       ├── MANIFEST.json / 来源对照.json / 验证结果.json
│       ├── prompts/             # 5张提示卡
│       └── skills/              # 9个技能（含agent-cultivation主技能的references+assets/templates）
└── raw/                        # 原版镜像（一字不改）
    ├── KNOWLEDGE_SKILLS.md     # 法旨文档
    ├── pages/index.html         # 站点首页
    ├── assets/                  # 主bundle + CSS
    ├── books/                   # 藏书阁原始JS（6个）
    └── chunks/                  # 视图chunk（7个，数据内联）
```

## 八大藏技能

| 藏 | 技能名 | 数量 | 用途 |
|---|---|---|---|
| 一·功法阁 | xiuzhen-gongfa | 53卡 | 提示词技巧查询与套用 |
| 二·境界谱 | xiuzhen-realms | 9境 | AI能力阶段判定与进阶 |
| 三·路引 | xiuzhen-roadmap | 9阶 | 系统性学习路径与任务 |
| 四·世界书 | xiuzhen-worldbook | 4篇 | 角色扮演世界观/类脑架构 |
| 五·法宝库 | xiuzhen-artifacts | 18件 | AI工具/框架选型 |
| 六·问答 | xiuzhen-dialogue | 5话题 | 师徒对话体概念讲解 |
| 七·藏书阁 | xiuzhen-library | 4部 | 深度阅读与体系化学习 |
| 八·阵图 | xiuzhen-diagrams | 4张 | Agent架构设计参考（SVG） |

## 第三方通用学习包扩展（v1.1新增）

`extensions/third-party-v1.1/` 原封不动收录第三方整理的通用AI学习包，与八大藏互补：八大藏给知识原文和修真化心法，第三方包给可执行的通用工作流程、验收场景和结构化模板。

### 第三方包9技能

| 技能 | 用途 |
|---|---|
| agent-cultivation | 方法入口，通用工作方法总纲（含12篇references+10个templates） |
| task-prompting | 任务提示设计，把模糊需求写成有效指令 |
| persona-state-design | 角色卡与性格状态设计，四层状态管理 |
| world-event-design | 世界书、事件书、状态演化设计 |
| tool-task-execution | 工具执行与任务规划，ReAct循环 |
| evidence-memory | 证据记忆与知识召回，RAG实践 |
| collaborative-work | 协作分工与交接，多Agent协同 |
| code-workbench | 代码修改与验证 |
| verified-improvement | 经验证明与技能改进，验证后迭代 |

### 第三方包核心资产

- **通用AI学习.md**（50KB单文件）：完整方法手册
- **24项实践方法**：可操作的工作方法+检查标准
- **15个验收场景**：具体场景+应有表现+失败迹象
- **10个结构化模板**：worldbook/eventbook/state-transition/task-graph/memory-record/improvement-record/prompt-presets JSON + persona-card/task-prompt/skill-template MD
- **4张Mermaid架构图**：执行循环/依赖规划/协作合并/角色记忆信息流
- **5张提示卡**：task-execution/persona-consistency/world-continuity/evidence-memory/verified-learning
- **学术论文引用**：ReAct/Reflexion/RAG/CoT/PHASE-Tree/Generative Agents/MemGPT/Self-Refine/Voyager

详见 `templates/THIRD-PARTY-ESSENTIALS.md` 精华提炼，原文以 `extensions/third-party-v1.1/` 为准。

## 核心公理

1. **文本即指令** — AI能力 = 上下文质量 × 模型能力
2. **三层流水线** — 胡思乱想→人格滤镜→精简输出
3. **稳定反向爆炸** — 0.7×(1+2)，第二层够强才能驾驭
4. **提示词 = 初始化指令 + 任务变量**
5. **上下文 ≠ 记忆**
6. **去AI味铁律**

## 使用方法

### 作为技能包使用
1. 将 `xiuzhen-skills/` 目录放入技能加载路径
2. 主入口 `SKILL.md` 会自动路由到八大藏子技能
3. 各子技能的 `data/` 目录含结构化JSON，可直接检索

### 直接查阅数据
- 功法/境界/路引/世界书/法宝/问答/阵图：读取对应 `skills/*/data/*.json`
- 藏书阁：读取 `skills/library/data/*.js`，格式为 `window.XXX = [{title, html}, ...]`
- 原版文件：`raw/` 目录，一字未改

### 模板套用
`templates/TEMPLATES.md` 含10套模板：SOUL角色卡、五段式提示词、角色卡设计、世界书条目、事件书、轻量类脑、图像风格、技能封装、提示词四问、去AI味检查清单。

## 原版镜像说明

`raw/` 目录是从站点 `https://challenge.dandanllab.top/` 原封不动拉取的全部文件，包括：
- 站点首页HTML
- 主bundle JS + CSS（hash随部署变动，当前为 `index-uyThFnHT.js`）
- 藏书阁6个JS分片
- 7个视图chunk（数据内联在压缩JS中）

所有文件MD5与站点一致，未做任何修改。

## 数据提取方式

各子技能 `data/` 目录下的JSON是从 `raw/chunks/` 视图chunk中提取的结构化数据：
- 功法阁：`GongfaView` chunk中 `var h=[...]` → 53项
- 境界谱：`RealmsView` chunk中 `var d=[...]` → 9项
- 路引：`RoadmapView` chunk中 `var u=[...]` → 9项
- 世界书：`WorldbookView` chunk中 `var h={...}` → 4键
- 法宝库：`ArtifactsView` chunk中 `var d=[...]` → 18项
- 问答：`DialogueView` chunk中 `var p={...}` → 5键
- 阵图：`DiagramsView` chunk中 `var u=[...]` → 4项

提取仅做格式转换（JS数组/对象 → JSON），内容一字未改。

## 功法卡境界分布

| 境界 | 数量 |
|---|---|
| 炼气期 | 4 |
| 筑基期 | 10 |
| 金丹期 | 9 |
| 元婴期 | 8 |
| 化神期 | 11 |
| 炼虚期 | 5 |
| 合体期 | 3 |
| 大乘期 | 1 |
| 渡劫期 | 2 |
| **合计** | **53** |
