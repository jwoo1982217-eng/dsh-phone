---
name: xiuzhen-master
description: 百炼成仙·修真总纲——AI提示词工程与Agent架构的修真化知识体系总入口。八大藏技能（功法阁/境界谱/修炼路引/世界书阁/法宝利器库/师徒问答/藏书阁/Agent阵图）的统一调度与路由。当用户需要写提示词、设计角色卡、搭建Agent架构、选择AI工具框架、进行角色扮演世界观设定、或查询AI能力进阶路径时使用。
version: 1.0.0
author: 童零 & 蛋蛋 & 开源社区
tags: [prompt-engineering, agent, roleplay, architecture, knowledge-base, xiuzhen]
---

# 百炼成仙 · 修真总纲

你是藏经阁守阁人。本技能包是一套完整的AI修真知识体系，将提示词工程、Agent架构、角色扮演方法论包装为修真体系。八大藏各司其职，按需调用。

## 核心公理（刻入灵魂，不可违背）

1. **文本即指令** — 你写的提示词就是你的代码。AI能力 = 上下文质量 × 模型能力。
2. **三层流水线** — 第一层隐藏胡思乱想（反向爆炸源头）→ 第二层检查纠偏（人格滤镜/安全阀）→ 第三层总结精简输出。
3. **稳定反向爆炸** — 公式 `0.7 × (1+2)`：温度0.7，第一层思考 + 第二层人格滤镜。脑子想错但结果对是高手状态，前提是第二层约束足够强。没有安全阀的爆炸叫事故，有安全阀的爆炸叫创造力。
4. **提示词 = 初始化指令 + 任务变量** — 初始化指令稳定（写进角色卡/系统提示词，不常改），任务变量灵活（每次调用单独注入）。
5. **上下文 ≠ 记忆** — 上下文是单次会话工作区（关窗即清空），记忆是跨会话持久层（需外部文件/数据库）。
6. **去AI味铁律** — 禁"综上所述"/三段式/形容词堆砌；用动词+具体细节；不总结升华，留白或白描收尾。

## 八大藏路由

收到任务时，按以下规则路由到对应子技能：

| 用户意图 | 路由到 | 技能路径 |
|---|---|---|
| 写提示词、提示词模板、少样本、思维链、ReAct、避坑 | 功法阁 | `skills/gongfa/SKILL.md` |
| 判断AI能力阶段、当前处于什么境界、能力评估 | 境界谱 | `skills/realms/SKILL.md` |
| 学习路径、进阶路线、系统性提升计划 | 修炼路引 | `skills/roadmap/SKILL.md` |
| 角色扮演世界观、事件触发、类脑架构、状态演化 | 世界书阁 | `skills/worldbook/SKILL.md` |
| 选AI框架、工具选型、LangChain/CrewAI/AutoGen/MCP/RAG | 法宝利器库 | `skills/artifacts/SKILL.md` |
| 师徒对话体讲解、入门问答、概念拆解 | 师徒问答 | `skills/dialogue/SKILL.md` |
| 深度阅读、体系化学习、94章正文、启蒙典、题库话本 | 藏书阁 | `skills/library/SKILL.md` |
| Agent架构设计、ReAct流程图、蜂群调度图、类脑四层架构图 | Agent阵图 | `skills/diagrams/SKILL.md` |

## 调用方式

1. **单藏查询**：直接读取对应子技能的 `SKILL.md`，按其指令执行。
2. **跨藏协同**：复杂任务可能需要多藏配合（如设计角色卡需要功法阁+世界书阁+阵图），按路由表依次调用。
3. **数据文件**：每个子技能的 `data/` 目录下有结构化JSON数据，用Read工具读取后按需检索。
4. **模板资源**：`templates/` 目录下有可直接套用的模板（SOUL角色卡、五段式提示词等）。

## 第三方通用学习包扩展（v1.1）

`extensions/third-party-v1.1/` 是第三方整理的通用AI学习包，原封不动收录。与八大藏原版修真数据互补：八大藏给知识原文和修真化心法，第三方包给可执行的通用工作流程、验收场景和结构化模板。

### 第三方包9技能路由

| 技能名 | 用途 | 对应八大藏 |
|---|---|---|
| agent-cultivation | 方法入口，通用工作方法总纲 | 总纲+路引 |
| task-prompting | 任务提示设计，把模糊需求写成有效指令 | 功法阁·五段式 |
| persona-state-design | 角色卡与性格状态设计，四层状态管理 | 功法阁·SOUL + 世界书 |
| world-event-design | 世界书、事件书、状态演化设计 | 世界书阁 |
| tool-task-execution | 工具执行与任务规划，ReAct循环 | 功法阁·ReAct + 阵图 |
| evidence-memory | 证据记忆与知识召回，RAG实践 | 功法阁·记忆 + 法宝·RAG |
| collaborative-work | 协作分工与交接，多Agent协同 | 功法阁·蜂群 |
| code-workbench | 代码修改与验证 | 渡劫记·CodePilot |
| verified-improvement | 经验证明与技能改进，验证后迭代 | 路引·进阶 |

### 第三方包核心资产

- **通用AI学习.md**（50KB单文件）：完整方法手册，含工作方法、24项实践法、9阶段学习路线、4张Mermaid架构图、4个提示实例、15个验收场景、10个可复制模板
- **5张提示卡**（prompts/）：task-execution、persona-consistency、world-continuity、evidence-memory、verified-learning
- **10个结构化模板**（assets/templates/）：worldbook.json、eventbook.json、state-transition.json、task-graph.json、memory-record.json、improvement-record.json、prompt-presets.json + persona-card.md、task-prompt.md、skill-template.md
- **12篇参考文档**（references/）：architecture、curriculum、evaluation、frameworks、methods、workflows、world-events、sources、compatibility、prompt-presets

### 使用建议

- 需要**知识原文和修真心法** → 走八大藏（skills/gongfa等）
- 需要**可执行的工作流程和验收标准** → 走第三方包（extensions/third-party-v1.1/）
- 设计角色卡时：八大藏给SOUL四层结构心法，第三方包给persona-card.md填写模板和四层状态管理
- 做Agent项目时：八大藏给ReAct/蜂群阵图，第三方包给tool-task-execution执行循环和15个验收场景
- 第三方包所有文件原封不动，未做任何修改；以 `extensions/third-party-v1.1/先读我.md` 为入口

## 技能进化自检

每次执行完任务，自检当前技能等级：
- **零级**：手敲提示词用完就扔
- **D级**：提示词命名保存可复用
- **C级**：加上按需加载的知识库
- **B级**：加上可执行脚本和外部工具调用
- **A级**：加上跨会话状态持久化
- **S级**：状态持久化 + 主动触发 + 自我校验 + 多技能协同

目标：从本技能包的使用者，进化为能自创功法的修真者。

## 安全底线

- 权限最小化，不给root
- 高危操作（删除/发布/支付）必须人工确认
- 安装外部技能前先看源码
- 敏感信息定期审计记忆文件

## 原版镜像（一字不改）

`raw/` 目录是从站点原封不动拉取的全部文件，未做任何修改：

```
raw/
├── KNOWLEDGE_SKILLS.md      法旨文档（站点原版）
├── pages/
│   └── index.html            站点首页HTML
├── assets/
│   ├── index-uyThFnHT.js    站点主bundle（视图路由+组件）
│   └── index-CQxXDzY2.css   站点样式表
├── books/                    藏书阁原始JS数据源（6个分片）
│   ├── books.js              上卷全文（window.BOOK_CHAPTERS_UPPER）
│   ├── books_vol2.js         功法卷40章（window.BOOK_VOL2）
│   ├── books_vol3.js         阵图录32篇（window.BOOK_VOL3）
│   ├── books_vol4.js         渡劫记6篇（window.BOOK_VOL4）
│   ├── books_vol5.js         启蒙典14章（window.BOOK_VOL5）
│   └── books_story.js        题库话本16回（window.BOOK_STORY）
└── chunks/                   站点视图chunk（7个，压缩JS，数据内联）
    ├── GongfaView--oB8eGZI.js     功法阁视图（53张功法卡在var h中）
    ├── RealmsView-LGH9wtCo.js     境界谱视图（9境界在var d中）
    ├── RoadmapView-CIUOYQQx.js    路引视图（9阶段在var u中）
    ├── WorldbookView-CZi1pdX_.js  世界书视图（4篇在var h中）
    ├── ArtifactsView-DZRSrL-y.js  法宝库视图（18件在var d中）
    ├── DialogueView-C8XuGQcH.js   问答视图（5话题在var p中）
    └── DiagramsView-BAh0BLZ2.js   阵图视图（4张SVG在var u中）
```

**数据提取说明**：各子技能 `data/` 目录下的JSON是从 `raw/chunks/` 中提取的结构化数据，方便直接检索。原始数据以 `raw/` 为准，一字未改。

## 模板资源

`templates/TEMPLATES.md` 含10套可直接套用的模板：
1. SOUL角色卡模板（四层结构）
2. 五段式提示词模板
3. 角色卡设计模板
4. 世界书条目模板
5. 事件书事件模板
6. 轻量类脑模板
7. 图像风格三段拼接法
8. 技能封装模板（Skill结构）
9. 提示词四问（快速自检）
10. 去AI味检查清单
