# 工具与框架地图

下列是阅读与选型入口，不是本包附带的程序。按已部署环境选择，框架数量、流行度或宣传倍数不能证明你的任务会更快。

| 名称或类别 | 用途 | 官方或研究入口 |
| --- | --- | --- |
| LangGraph | 有状态任务和图式工作流 | [官方文档](https://docs.langchain.com/oss/python/langgraph/overview) |
| CrewAI | 执行者、任务与团队的组织 | [官方文档](https://docs.crewai.com/) |
| Microsoft Agent Framework | 智能体与协作工作流 | [官方源码](https://github.com/microsoft/agent-framework) |
| DeepSeek Harness | 用插件配置模型、工具与助手 | [官方源码](https://github.com/deepseek-ai/deepseek-harness) |
| OpenClaw | 助手与实际工具、通信入口的集成 | [官方源码](https://github.com/openclaw/openclaw) |
| JiuwenSwarm | 基于 openJiuwen 的协作与技能体系 | [官方源码](https://github.com/openJiuwen-ai/jiuwenswarm) |
| MCP | 工具、资源、提示的上下文接口 | [官方架构说明](https://modelcontextprotocol.io/docs/learn/architecture) |
| RAG | 在回答前检索相关知识 | [原始论文](https://arxiv.org/abs/2005.11401) |
| 向量检索存储 | 供检索系统保存向量和关联资料 | 如 Qdrant、Milvus、Chroma；与实际数据规模和权限需求匹配 |
| 追踪与评估 | 记录执行、比较任务结果 | 如 LangSmith；也可用宿主日志与自己的验收集 |
| OpenAI Swarm | 学习轻量协作与交接概念 | [历史教育项目](https://github.com/openai/swarm)，不把它当作生产系统的默认部署方案 |
| SWE-bench | 了解真实代码修复任务的评估方式 | 评测分数和软件版本需查询实际发布记录；本包没有附带评测数据 |

阅读主框架说明后仍需核对目标设备支持、账号、依赖与工具权限。手机网页看起来和桌面相同，不代表桌面原生库或每项工具都能运行。
